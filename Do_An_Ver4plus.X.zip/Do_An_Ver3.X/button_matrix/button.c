#include "button.h"

unsigned int key_code[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
//unsigned char arrayMaskOutputOfKey [8] = {0x80,0x40,0x20,0x10,0x01,0x02,0x04,0x08};
//unsigned char arrayMaskInputOfKey [8] = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};
unsigned char arrayMaskOutputOfKey [4] = {0x10,0x20,0x40,0x80};
unsigned char arrayMaskInputOfKey [4] = {0x1,0x02,0x04,0x08};

void init_key_matrix()
{
	TRIS_BUTTON = 0x0f; 
	PORT_BUTTON = 0xff;
}

void init_key_matrix_with_uart_i2c()
{
        TRIS_BUTTON = TRIS_BUTTON | 0x07;
        TRIS_BUTTON = TRIS_BUTTON & 0b11011111; //RC5 Output
	PORT_BUTTON = 0xff;
}

void scan_key_matrix()
{
	int i,j;
	for(i=0;i<MAX_ROW;i++)     
	{
		PORT_BUTTON = ~arrayMaskOutputOfKey[i];
		for(j=0;j<MAX_COL;j++)
		{ 
			if((PORT_BUTTON & arrayMaskInputOfKey[j]) == 0)  
				key_code[i*MAX_ROW+j] = key_code[i*MAX_ROW+j] + 1;
			else
				key_code[i*MAX_ROW+j] = 0;   
		}
	}
}

void scan_key_matrix_with_uart_i2c()
{
	int i=0,j=0;
        i=1;
	{
		PORT_BUTTON = PORT_BUTTON & ~arrayMaskOutputOfKey[i];
		for(j=0;j<3;j++)
		{
			if((PORT_BUTTON & arrayMaskInputOfKey[j]) == 0)
				key_code[i*MAX_ROW+j] = key_code[i*MAX_ROW+j] + 1;
			else
				key_code[i*MAX_ROW+j] = 0;
		}
	}
}

//ham nay de giup cac ban hieu ro viec quet ma tran phim
//Sau khi da hieu ve cach quet ma tran phim thi xoa di, hoac luu lai o mot file khac
void button_delay_ms(int value)
{
	int i,j;
	for(i=0;i<value;i++)
		for(j=0;j<238;j++);
}

void scan_key_matrix_demo() 
{
	int i,j;
	for(i=0;i<MAX_ROW;i++)     
	{
		PORT_BUTTON = ~arrayMaskOutputOfKey[i];
		for(j=0;j<MAX_COL;j++)
		{ 
			key_code[i*MAX_ROW+j] = 0;   
			if((PORT_BUTTON & arrayMaskInputOfKey[j]) == 0)  
			{
				key_code[i*MAX_ROW+j] = 1;
			}
		}
		PORTB = PORT_BUTTON;
		button_delay_ms(1000);
	}
}

unsigned char isButtonMode()
{
    if (key_code[4] == 1)
        return 1;
    else
        return 0;
}

unsigned char isButtonModeHold()
{
    if (key_code[4] == 10)
        return 1;
    else
        return 0;
}

unsigned char isButtonAlarm()
{
    if (key_code[8] == 1)
        return 1;
    else
        return 0;
}

unsigned char isButtonAlarmHold()
{
    if (key_code[8] == 10)
        return 1;
    else
        return 0;
}

unsigned char isButtonIncrease()
{
    if (key_code[5] == 1 || (key_code[5] > 10 && key_code[5]%3 == 1))
        return 1;
    else
        return 0;
}

unsigned char isButtonDecrease()
{
    if (key_code[9] == 1 || (key_code[9] > 10 && key_code[9]%3 == 1))
        return 1;
    else
        return 0;
}
unsigned char isButton1(){
    if(key_code[0] == 1 || (key_code[0] > 10 && key_code[0]%3 == 1))
        return 1;
    else 
        return 0;
}
unsigned char isButton2(){
    if(key_code[1] == 1 || (key_code[1] > 10 && key_code[1]%3 == 1))
        return 1;
    else 
        return 0;
}
unsigned char isButton3(){
    if(key_code[2] == 1 || (key_code[2] > 10 && key_code[2]%3 == 1))
        return 1;
    else 
        return 0;
}
unsigned char isButtonA(){
    if(key_code[3] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButton4(){
    if(key_code[4] == 1 || (key_code[4] > 10 && key_code[4]%3 == 1))
        return 1;
    else 
        return 0;
}
unsigned char isButton5(){
    if(key_code[5] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButton6(){
    if(key_code[6] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButtonB(){
    if(key_code[7] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButton7(){
    if(key_code[8] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButton8(){
    if(key_code[9] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButton9(){
    if(key_code[10] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButtonC(){
    if(key_code[11] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButtonAsterisk(){
    if(key_code[12] == 1 || (key_code[12] > 10 && key_code[12]%3 == 1))
        return 1;
    else 
        return 0;
}
unsigned char isButton0(){
    if(key_code[13] == 1)
        return 1;
    else 
        return 0;
}
unsigned char isButtonHash(){
    if(key_code[14] == 1 || (key_code[14] > 10 && key_code[14]%3 == 1))
        return 1;
    else 
        return 0;
}
unsigned char isButtonD(){
    if(key_code[15] == 1)
        return 1;
    else 
        return 0;
}