
#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"


#define SETSECOND   1
#define SETMINUTE   2
#define SETHOUR     3
#define SETDAY      4  
#define SETDATE     5
#define SETMONTH    6
#define SETYEAR     7
#define WAIT        30

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6


unsigned char secondSet = 0;
unsigned char minuteSet = 0;
unsigned char hourSet = 0;
unsigned char daySet = 0;
unsigned char dateSet = 0;
unsigned char monthSet = 0;
unsigned char yearSet = 0;
unsigned char modeSet = 0;
unsigned char tmp;
unsigned char blinkSet = 0;
unsigned char first = 0, secon = 0;
unsigned char doneSet = 0;
unsigned char setting = WAIT;
enum key{button0,button1,button2,button3,button4,button5,button6,button7,button8,button9,buttonAsterisk,buttonHash};
unsigned char btn = WAIT;
void DisplayTimeSettings();

static int monthArray[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
unsigned char dayOfWeek(unsigned char date, int month, int year){
    year += 2000;
        year -= month < 3;
    return ( year + year/4 - year/100 + year/400 + monthArray[month - 1] + date) % 7;
}


void validateSetting(unsigned char second,unsigned char minute,unsigned char hour,unsigned char date,unsigned char month, unsigned char year){
    if(second > 59){
        second %= 60;
        minute += 1;
    }
    if(minute > 59){
        minute %=60;
        hour += 1;
    }
    if(hour > 23){
        tmp = hour/24;
        hour %= 24;
        date += tmp;
    }
    if(month==1 || month==3 || month==5 || month==7 || month== 8|| month==10||month==12){
        if(date > 31){
            date %= 32;
            month+=1;
        }
    }
    if(month==4 || month==6 || month==9 || month==11){
        if(date > 30){
            date %= 31;
            month += 1;
        }

    }
    if(month == 2 && (year%4 == 0)){
        if(date > 29){
            date %= 30;
                  month += 1;
        }
  
    }
    else{
        if(date > 28){
            date %= 29;
                   month += 1;
        }
 
    }
    if(month > 12){
        month = 1;
        year++;
    }
    if(year > 99){
        year = 99;
    }
    
    //day = dayOfWeek(date, month, year);
    
    Write_DS1307(ADDRESS_SECOND, second);
    Write_DS1307(ADDRESS_MINUTE, minute);
    Write_DS1307(ADDRESS_HOUR, hour);
    //Write_DS1307(ADDRESS_DAY, day);
    Write_DS1307(ADDRESS_DATE, date);
    Write_DS1307(ADDRESS_MONTH, month);
    Write_DS1307(ADDRESS_YEAR, year);
    setZone(7);
}
void validate(char hour,unsigned char day,unsigned char date,unsigned char month, unsigned char year){
    if(hour > 23){
        hour %= 24;
        day += 1;
        date += 1;
        if(day > 7){
            day = 1;
        }
        if(month==1 || month==3 || month==5 || month==7 || month== 8|| month==10||month==12){
            if(date > 31){
                date = 1;
                month+=1;
            }
        }
        else if(month==4 || month==6 || month==9 || month==11){
            if(date > 30){
                date = 1;
                month += 1;
            }
        }
        else if(month == 2 && (year%4 == 0)){
            if(date > 29){
                date = 1;
                month += 1;
            }

        }
        else{
            if(date > 28){
                date = 1;
                month += 1;
            }
        }
        if(month > 12){
            month = 1;
            year++;
        }
        if(year > 99){
            year = 0;
        }
    }
    else if(hour < 0){
        hour += 24;
        day -= 1;
        date -= 1;
        if(day < 1){
            day = 7;
        }
        if(month==1 || month==2 || month==4 || month==6 || month== 8|| month==9||month==11){
            if(date < 1){
                date = 31;
                month-=1;
            }
        }
        else if(month==5 || month==7 || month==10 || month==12){
            if(date < 1){
                date = 30;
                month -= 1;
            }
        }
        else if(month == 3 && (year%4 == 0)){
            if(date < 1){
                date = 29;
                month -= 1;
            }
        }
        else{
            if(date < 1){
                date = 28;
                month -= 1;
            }
        }
        if(month < 1){
            month = 12;
            year--;
        }
        if(year < 0){
            year = 99;
        }
    }
    Write_DS1307(ADDRESS_HOUR, hour);
    Write_DS1307(ADDRESS_DAY, day);
    Write_DS1307(ADDRESS_DATE, date);
    Write_DS1307(ADDRESS_MONTH, month);
    Write_DS1307(ADDRESS_YEAR, year);
}
void buttonSetting(unsigned char *set){
    switch (btn){
        case WAIT:
            if(isButton0()){
                btn = button0;
            }
            else if(isButton1()){
                btn = button1;
            }
            else if(isButton2()){
                btn = button2;
            }
            else if(isButton3()){
                btn = button3;
            }
            else if(isButton4()){
                btn = button4;
            }
            else if(isButton5()){
                btn = button5; 
            }
            else if(isButton6()){
                btn = button6;
            }
            else if(isButton7()){
                btn = button7;
            }
            else if(isButton8()){
                btn = 8;
            }
            else if(isButton9()){
                btn = button9;
            }
            break;
        case button0:
            doneSet = 1;
            *set = 0;
            btn = WAIT;
            break;
        case button1:
            doneSet = 1;
            *set = 1;
            btn = WAIT;
            break;
        case button2:
            doneSet = 1;
            *set = 2;
            btn = WAIT;
            break;
        case button3:
            doneSet = 1;
            *set = 3;
            btn = WAIT;
            break;
        case button4:
            doneSet = 1;
            *set = 4;
            btn = WAIT;
            break;
        case button5:
            doneSet = 1;
            *set = 5;
            btn = WAIT;
            break;
        case button6:
            doneSet = 1;
            *set = 6;
            btn = WAIT;
            break;
        case button7:
            doneSet = 1;
            *set = 7;
            btn = WAIT;
            break;
        case button8:
            doneSet = 1;
            *set = 8;
            btn = WAIT;
            break;
        case button9:
            doneSet = 1;
            *set = 9;
            btn = WAIT;
            break;
    }
}
void settingTime(){
    switch(setting){
        case WAIT:
            daySet = Read_DS1307(ADDRESS_DAY);
            hourSet = Read_DS1307(ADDRESS_HOUR);
            minuteSet = Read_DS1307(ADDRESS_MINUTE);
            secondSet = Read_DS1307(ADDRESS_SECOND);
            dateSet = Read_DS1307(ADDRESS_DATE);
            monthSet = Read_DS1307(ADDRESS_MONTH);
            yearSet = Read_DS1307(ADDRESS_YEAR);
            DisplayTimeSettings();
            setting = SETHOUR;
            //LcdClearS();

                break;
        case SETSECOND:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,10," ");
                }
                buttonSetting(&first);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    LcdPrintNumS(0,10,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,11," ");
                }
                buttonSetting(&secon);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    secondSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(0,11,secondSet%10);
                    setting = SETDATE;
                }
            }
            break;
        case SETMINUTE:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,7," ");
                }
                buttonSetting(&first);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    LcdPrintNumS(0,7,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,8," ");
                }
                buttonSetting(&secon);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    minuteSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(0,8,minuteSet%10);
                    setting = SETSECOND;
                }
            }
            break;
        case SETHOUR:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,4," ");
                }
                buttonSetting(&first);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    LcdPrintNumS(0,4,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,5," ");
                }
                buttonSetting(&secon);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    hourSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(0,5,hourSet%10);
                    setting = SETMINUTE;
                }
            }
            break;
        case SETDATE:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,6," ");
                }
                buttonSetting(&first);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    LcdPrintNumS(1,6,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,7," ");
                }
                buttonSetting(&secon);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    dateSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(1,7,dateSet%10);
                    setting = SETMONTH;
                }
            }
            break;
        case SETMONTH:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(isButton0())
            {
                monthSet += 1;
            if(monthSet > 12)
                monthSet = 1;
            }
            blinkSet = (blinkSet+1)%20;
            if(blinkSet > 15){
                LcdPrintStringS(1,2,"   ");
            }
            switch(monthSet){
                case 1:
                    LcdPrintStringS(1,2,"JAN");
                    break;
                case 2:
                    LcdPrintStringS(1,2,"FEB");
                    break;
                case 3:
                    LcdPrintStringS(1,2,"MAR");
                    break;
                case 4:
                    LcdPrintStringS(1,2,"APR");
                    break;
                case 5:
                    LcdPrintStringS(1,2,"MAY");
                    break;
                case 6:
                    LcdPrintStringS(1,2,"JUN");
                    break;
                case 7:
                    LcdPrintStringS(1,2,"JUL");
                    break;
                case 8:
                    LcdPrintStringS(1,2,"AUG");
                    break;
                case 9:
                    LcdPrintStringS(1,2,"SEP");
                    break;
                case 10:
                    LcdPrintStringS(1,2,"OCT");
                    break;
                case 11:
                    LcdPrintStringS(1,2,"NOV");
                    break;
                case 12:
                    LcdPrintStringS(1,2,"DEC");
                    break;
            }
            if(isButtonAsterisk()){
                setting = SETYEAR;
            }
            break;
        case SETYEAR:
            if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(modeSet == 0){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,11," ");
                }
                buttonSetting(&first);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    LcdPrintNumS(1,11,first);
                }
            }
            else if (modeSet == 1){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,12," ");
                }
                buttonSetting(&secon);
                if(doneSet){
                    modeSet = 2;
                    doneSet = 0;
                    yearSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(1,12,yearSet%10);
                }
                
            }
            else if(modeSet == 2){
                if(isButtonAsterisk()){
                    modeSet = 0;
                    validateSetting(secondSet,minuteSet,hourSet,dateSet,monthSet,yearSet);
                    //LcdPrintNumS(1,1,monthSet);
                    daySet = dayOfWeek(dateSet, monthSet, yearSet);
                    Write_DS1307(ADDRESS_DAY, daySet);
                    setting = WAIT;
                    setState(CLOCK);
                }
            }
            /*if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,11," ");
                }
                buttonSetting(&first);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    LcdPrintNumS(1,12,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,9,"    ");
                }
                buttonSetting(&secon);
                if(doneSet){
                    modeSet ^= 0x01;
                    doneSet = 0;
                    yearSet = first*10+secon;
                    first = 0;
                    secon = 0;
                }
                                    LcdPrintNumS(1,9,20);
                    LcdPrintNumS(1,11,yearSet);
                if(isButtonAsterisk()){
                    validateSetting(secondSet,minuteSet,hourSet,dateSet,monthSet,yearSet);
                    setting = WAIT;
                    setState(CLOCK);
                }
            }*/
            break;
    }
}

void DisplayTimeSettings()
{
    //////day
    LcdClearS();
    switch(daySet)
    {
        case 1:
            LcdPrintStringS(0,0,"SUN");
            break;
        case 2:
            LcdPrintStringS(0,0,"MON");
            break;
        case 3:
            LcdPrintStringS(0,0,"TUE");
            break;
        case 4:
            LcdPrintStringS(0,0,"WED");
            break;
        case 5:
            LcdPrintStringS(0,0,"THU");
            break;
        case 6:
            LcdPrintStringS(0,0,"FRI");
            break;
        case 7:
            LcdPrintStringS(0,0,"SAT");
            break;
    }
    if(hourSet < 10)
    {
        LcdPrintStringS(0,4,"0");
        LcdPrintNumS(0,5,hourSet);
    }
    else
        LcdPrintNumS(0,4,hourSet);
    
    LcdPrintStringS(0,6,":");
    if(minuteSet < 10)
    {
        LcdPrintStringS(0,7,"0");
        LcdPrintNumS(0,8,minuteSet);
    }
    else
        LcdPrintNumS(0,7,minuteSet);

    LcdPrintStringS(0,9,":");
    if(secondSet < 10)
    {
        LcdPrintStringS(0,10,"0");
        LcdPrintNumS(0,11,secondSet);
    }
    else
        LcdPrintNumS(0,10,secondSet);
    
    switch(monthSet)
    {
        case 1:
            LcdPrintStringS(1,2,"JAN");
            break;
        case 2:
            LcdPrintStringS(1,2,"FEB");
            break;
        case 3:
            LcdPrintStringS(1,2,"MAR");
            break;
        case 4:
            LcdPrintStringS(1,2,"APR");
            break;
        case 5:
            LcdPrintStringS(1,2,"MAY");
            break;
        case 6:
            LcdPrintStringS(1,2,"JUN");
            break;
        case 7:
            LcdPrintStringS(1,2,"JUL");
            break;
        case 8:
            LcdPrintStringS(1,2,"AUG");
            break;
        case 9:
            LcdPrintStringS(1,2,"SEP");
            break;
        case 10:
            LcdPrintStringS(1,2,"OCT");
            break;
        case 11:
            LcdPrintStringS(1,2,"NOV");
            break;
        case 12:
            LcdPrintStringS(1,2,"DEC");
            break;
    }

    LcdPrintStringS(1,5," ");
    if(dateSet < 10)
    {
        LcdPrintStringS(1,6," ");
        LcdPrintNumS(1,7,dateSet);
    }
    else
    LcdPrintNumS(1,6,dateSet);
    LcdPrintStringS(1,8," ");
    LcdPrintNumS(1,9,20);
    if (yearSet >= 10)
        LcdPrintNumS(1,11,yearSet);
    else
    {
        LcdPrintNumS(1,11,0);
        LcdPrintNumS(1,12,yearSet);
    }
}