
#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"

#define     FR          1 // France
#define     EG          2 // Egypt
#define     RU          3 // Moscow, Russia
#define     OM          4 // Oman
#define     MV          5 // Maldives
#define     BT          6 // Bhutan
#define     VN          7 // Viet Nam
#define     CN          8 // China
#define     JP          9 // Japan
#define     WAIT        30

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6

unsigned char timeZone = WAIT;
unsigned char secondZone = 0,minuteZone = 0;
char hourZone = 0;
unsigned char dayZone = 0;
signed char dateZone = 0,monthZone = 0,yearZone = 0;
unsigned char temp;
unsigned char modeZone = 1;
void readTime(void){
    secondZone = Read_DS1307(ADDRESS_SECOND);
    minuteZone = Read_DS1307(ADDRESS_MINUTE);
    hourZone = Read_DS1307(ADDRESS_HOUR);
    dayZone = Read_DS1307(ADDRESS_DAY);
    dateZone = Read_DS1307(ADDRESS_DATE);
    monthZone = Read_DS1307(ADDRESS_MONTH);
    yearZone = Read_DS1307(ADDRESS_YEAR);
}
void writeTime(void){
    Write_DS1307(ADDRESS_SECOND, secondZone);
    Write_DS1307(ADDRESS_MINUTE, minuteZone);
    Write_DS1307(ADDRESS_HOUR, hourZone);
    Write_DS1307(ADDRESS_DAY, dayZone);
    Write_DS1307(ADDRESS_DATE, dateZone);
    Write_DS1307(ADDRESS_MONTH, monthZone);
    Write_DS1307(ADDRESS_YEAR, yearZone);
}

void selectTimeZone(void){
    
    temp = getZone();
    switch (timeZone){
        case WAIT:
            if(isButtonAsterisk()){
                modeZone++;
                if(modeZone > 3) modeZone =1;
            }
            if(modeZone == 1){
                LcdPrintStringS(0,0,"1.FRANCE 2.EGYPT");
                LcdPrintStringS(1,0,"3.RUSSIA        ");
                if(isButton1()){
                    timeZone = FR;
                }
                else if(isButton2()){
                    timeZone = EG;
                }
                else if(isButton3()){
                    timeZone = RU;
                }
            }
            else if(modeZone== 2){
                LcdPrintStringS(0,0,"4.OMAN 6.BHUTAN ");
                LcdPrintStringS(1,0,"5.MALDIVES      ");
                if(isButton4()){
                    timeZone = OM;
                }
                else if(isButton5()){
                    timeZone = MV;
                }
                else if(isButton6()){
                    timeZone = BT;
                }
            }
            else if(modeZone == 3){
                LcdPrintStringS(0,0,"7.VIETNAM       ");
                LcdPrintStringS(1,0,"8.CHINA  9.JAPAN");
                if(isButton7()){
                    timeZone = VN;
                }
                else if(isButton8()){
                    timeZone = CN;
                }
                else if(isButton9()){
                    timeZone = JP;
                }
            }
            break;
        case FR:
            //readTime();
            //hourZone += (VN-temp);
            //writeTime();
            setZone(FR);
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            break;
        case EG:
            //readTime();
            //hourZone += (CN-temp);
            //writeTime();
            setZone(EG);
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            break;
        case RU:
            //readTime();
            //hourZone += (JP-temp);
            //writeTime();
            setZone(RU);
            setDone(0);
            timeZone = WAIT; 
            setState(CLOCK);
            break;
        case OM:
            //readTime();
            //hourZone += (VN-temp);
            //writeTime();
            setZone(OM);
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            break;
        case MV:
            //readTime();
            //hourZone += (CN-temp);
            //writeTime();
            setZone(MV);
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            break;
        case BT:
            //readTime();
            //hourZone += (JP-temp);
            //writeTime();
            setZone(BT);
            setDone(0);
            timeZone = WAIT; 
            setState(CLOCK);
            break;
        case VN:
            //readTime();
            //hourZone += (VN-temp);
            //writeTime();
            setZone(VN);
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            break;
        case CN:
            //readTime();
            //hourZone += (CN-temp);
            //writeTime();
            setZone(CN);
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            break;
        case JP:
            //readTime();
            //hourZone += (JP-temp);
            //writeTime();
            setZone(JP);
            setDone(0);
            timeZone = WAIT; 
            setState(CLOCK);
            break;             
    }
}
