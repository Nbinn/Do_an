#include "main.h"
#include <p18f4620.h>
#include "timer\timer.h"
#include "interrupt\interrupt.h"
#include "button_matrix\button.h"
#include "lcd\lcd.h"
#include "i2c\i2c.h"
#include "worldclock\worldclock.h"

#pragma config OSC		= HS
#pragma config FCMEN            = OFF
#pragma config IESO		= OFF
#pragma config PWRT		= OFF
#pragma config BOREN            = ON
#pragma config BORV		= 0
#pragma config WDT		= OFF
#pragma config MCLRE            = ON
#pragma config LPT1OSC          = OFF
#pragma config PBADEN           = OFF
#pragma config CCP2MX           = PORTC
#pragma config STVREN           = ON
#pragma config LVP		= OFF
#pragma config XINST            = OFF
#pragma config DEBUG            = OFF
#pragma config CP0 		= OFF
#pragma config CP1 		= OFF
#pragma config CP2 		= OFF
#pragma config CP3 		= OFF
#pragma config CPB 		= OFF
#pragma config CPD 		= OFF
#pragma config WRT0		= OFF
#pragma config WRT1		= OFF
#pragma config WRT2		= OFF
#pragma config WRT3		= OFF
#pragma config WRTB		= OFF
#pragma config WRTC		= OFF
#pragma config WRTD		= OFF
#pragma config EBTR0            = OFF
#pragma config EBTR1            = OFF
#pragma config EBTR2            = OFF
#pragma config EBTR3            = OFF
#pragma config EBTRB            = OFF

// Noi khai bao hang so
#define     LED     PORTD
#define     ON      1
#define     OFF     0
#define     ENABLE      1
#define     DISABLE     0

#define     ADDRESS_FIRST_PROGRAM   0x20

#define     ADDRESS_HOUR_ALARM      0x10
#define     ADDRESS_MINUTE_ALARM    0x11
#define     ADDRESS_BIT_ALARM       0x12
#define     ADDRESS_FLAG_ALARM      0x13

#define     INIT_SYSTEM         0
#define     SET_HOUR_ALARM      1
#define     SET_MINUTE_ALARM    2
#define     BIT_ALARM           3
#define     COMPARE             4
#define     ALARM               5

#define     SET_HOUR            6
#define     SET_MINUTE          7
#define     SET_DAY             8
#define     SET_DATE            9
#define     SET_MONTH           10
#define     SET_YEAR            11

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6

#define     FR          1 // France
#define     EG          2 // Egypt
#define     RU          3 // Moscow, Russia
#define     OM          4 // Oman
#define     MV          5 // Maldives
#define     BT          6 // Bhutan
#define     VN          7 // Viet Nam
#define     CN          8 // China
#define     JP          9 // Japan
// Noi khai bao bien toan cuc
unsigned char second = 0,minute = 0;
char hour = 0;
unsigned char day = 0;
unsigned char date = 0,month = 0,year = 0;
unsigned char statusSetUpAlarm = INIT_SYSTEM;
unsigned char statusSetUpTime = INIT_SYSTEM;
unsigned char statusAlarm = INIT_SYSTEM;
unsigned char hourAlarm = 0, minuteAlarm = 0, bitAlarm = 0;
unsigned char timeBlink = 0;
unsigned int timeAlarm = 0;
unsigned char flagAlarm = 0;
//unsigned char tmp = 0;
unsigned char bitEnable = ENABLE;
unsigned char minuteStop = 0, secondStop = 0, centisecondStop = 0, bitStop = 0;
unsigned char hourCount = 0, minuteCount = 0, secondCount = 0, bitCount = 0;
unsigned char hourFocus = 0, minuteFocus = 0, secondFocus = 0, bitFocus = 0;
unsigned char state = CLOCK;
unsigned char mode = 0;
signed char zone = EG;
unsigned char done = 0;
// Khai bao cac ham co ban IO
void init_system(void);
void delay_ms(int value);

void SetupTimeForRealTime(void);
void SetupForFirstProgram(void);
void ReadDataFromDS1307(void);
void BaiTap_I2C(void);
void DisplayTime(void);
void SetUpAlarm(void);
void SetUpTime(void);

void DisplayAlarmTime(void);
unsigned char CompareTime(void);
void Alarm(void);
void DisplayStopWatch(void);
void DisplayCountDown(void);
void DisplayFocus(void);
void fsm(void);
signed char getZone(void);
void setZone(signed char timeZone);
void setDone(signed char timeDone);
////////////////////////////////////////////////////////////////////
//Hien thuc cac chuong trinh con, ham, module, function duoi cho nay
////////////////////////////////////////////////////////////////////
void main()
{
	unsigned int k = 0;
        
	init_system();
//        lcd_clear();
        LcdClearS();
        SetupForFirstProgram();
        //SetupTimeForRealTime();
        delay_ms(1000);
        LcdPrintString(0,6,"ALARM CLOCK");    
        ReadDataFromDS1307();
        //delay_ms(2000);
	while (1)
	{
            while (!flag_timer3);
            flag_timer3 = 0;
            scan_key_matrix();
            k = (k+1)%2000;
            /*switch(tmp){
                case 0:
                    DisplayTime();
                    delay_ms(2000);
                    tmp++;
                    break;
                case 1:
                    DisplayAlarmTime();
                    delay_ms(2000);
                    tmp++;
                    break;
                case 2: 
                    DisplayStopWatch();
                    delay_ms(2000);
                    tmp++;
                    break;
                case 3:
                    DisplayCountDown();
                    delay_ms(2000);
                    tmp++;
                    break;
                case 4:
                    DisplayFocus();
                    delay_ms(2000);
                    tmp = 0;
                    break;
            }*/
            fsm();
            DisplayLcdScreenOld();
	}
}
void fsm(){
    switch (state){
        case SELECT:
            LcdClearS();
            if(isButtonAsterisk()){
                mode ^= 0x01;
            }
            if(!mode){
                LcdPrintStringS(0,0,"1.CLOCK  2.ALARM");
                LcdPrintStringS(1,0,"3.FOCUS  4.ZONE");
                if(isButton1()){
                    state = CLOCK;
                }
                else if(isButton2()){
                    state = ALARM;
                }
                else if(isButton3()) {
                    state = FOCUS;
                }
                else if(isButton4()){
                    state = ZONE;
                }
            }
            else{
                LcdPrintStringS(0,0,"5.STOPWATCH     ");
                LcdPrintStringS(1,0,"6.COUNTDOWN     ");
                if(isButton4()){
                    state = STOPWATCH;
                }
                else if(isButton5()){
                    state = COUNTDOWN;
                }
            }
            break;
        case CLOCK:
            if(isButtonHash()){
                state = SELECT;
                mode = 0;
            }
            LcdClearS();
            DisplayTime();
            break;
        case ALARMTIME:
            if(isButtonHash()){
               state = SELECT;
               mode = 0;
            }
            DisplayAlarmTime();
            break;
        case FOCUS: 
            if(isButtonHash()){
               state = SELECT;
               mode = 0;
            }
            DisplayFocus();
            break;
        case ZONE:
            if(isButtonHash()){
               state = SELECT;
               mode = 0;
            }
            selectTimeZone();
            if(done){
                done = 0;
                state = CLOCK;
            }
            break;
        case STOPWATCH:
            if(isButtonHash()){
               state = SELECT;
               mode = 0;
            }
            DisplayStopWatch();
            break;
        case COUNTDOWN:
            if(isButtonHash()){
               state = SELECT;
               mode = 0;
            }
            DisplayCountDown();
            break;
        }
}
signed char getZone(){
    return zone;
}
void setZone(signed char timeZone){
    zone = timeZone;
}
void setDone(signed char timeDone){
    done = timeDone;
}
// Hien thuc cac module co ban cua chuong trinh
void delay_ms(int value)
{
	int i,j;
	for(i=0;i<value;i++)
		for(j=0;j<238;j++);
}

void init_system()
{
        TRISB = 0x00;		//setup PORTB is output
        TRISD = 0x00;
        init_lcd();
//        LED = 0x00;
        init_interrupt();
        delay_ms(1000);
        init_timer0(4695);//dinh thoi 1ms sai so 1%
        init_timer1(9390);//dinh thoi 2ms
        init_timer3(46950);//dinh thoi 10ms
        SetTimer0_ms(2);
        SetTimer1_ms(10);
        SetTimer3_ms(50); //Chu ky thuc hien viec xu ly input,proccess,output
        init_key_matrix();
        init_i2c();
}

///////I2C
void SetupTimeForRealTime()
{
    second = 00;
    minute = 20;
    hour = 11;
    day = 2;
    date = 13;
    month = 12;
    year = 21;
    Write_DS1307(ADDRESS_SECOND, second);
    Write_DS1307(ADDRESS_MINUTE, minute);
    Write_DS1307(ADDRESS_HOUR, hour);
    Write_DS1307(ADDRESS_DAY, day);
    Write_DS1307(ADDRESS_DATE, date);
    Write_DS1307(ADDRESS_MONTH, month);
    Write_DS1307(ADDRESS_YEAR, year);
}

void SetupForFirstProgram()
{
    if(Read_DS1307(ADDRESS_FIRST_PROGRAM) != 0x22)
    {
        SetupTimeForRealTime();
        Write_DS1307(ADDRESS_HOUR_ALARM, 0);
        Write_DS1307(ADDRESS_MINUTE_ALARM, 0);
        Write_DS1307(ADDRESS_BIT_ALARM, 0);
        Write_DS1307(ADDRESS_FLAG_ALARM, 0);

        Write_DS1307(ADDRESS_FIRST_PROGRAM, 0x22);
    }
}

void ReadDataFromDS1307()
{
    hourAlarm = Read_DS1307(ADDRESS_HOUR_ALARM);
    minuteAlarm = Read_DS1307(ADDRESS_MINUTE_ALARM);
    bitAlarm = Read_DS1307(ADDRESS_BIT_ALARM);
    flagAlarm = Read_DS1307(ADDRESS_FLAG_ALARM);
}
void BaiTap_I2C()
{
    second = Read_DS1307(ADDRESS_SECOND);
    minute = Read_DS1307(ADDRESS_MINUTE);
    hour = Read_DS1307(ADDRESS_HOUR);
    day = Read_DS1307(ADDRESS_DAY);
    date = Read_DS1307(ADDRESS_DATE);
    month = Read_DS1307(ADDRESS_MONTH);
    year = Read_DS1307(ADDRESS_YEAR);
    
    LcdPrintNumS(0,0,year);
    LcdPrintNumS(0,3,month);
    LcdPrintNumS(0,6,date);
    LcdPrintNumS(0,9,day);
    LcdPrintNumS(1,0,hour);
    LcdPrintNumS(1,3,minute);
    LcdPrintNumS(1,6,second);
}

void DisplayTime()
{
    second = Read_DS1307(ADDRESS_SECOND);
    minute = Read_DS1307(ADDRESS_MINUTE);
    hour = Read_DS1307(ADDRESS_HOUR);
    day = Read_DS1307(ADDRESS_DAY);
    date = Read_DS1307(ADDRESS_DATE);
    month = Read_DS1307(ADDRESS_MONTH);
    year = Read_DS1307(ADDRESS_YEAR);

    if (zone == FR)
    {
        hour -= 6;
    }
    else if (zone == EG)
    {
        hour -= 5;
    }
    else if (zone == RU)
    {
        hour -= 4;
    }
    else if (zone == OM)
    {
        hour -= 3;
    }
    else if (zone == MV)
    {
        hour -= 2;
    }
    else if (zone == BT)
    {
        hour -= 1;
    }
    else if (zone == CN)
    {
        hour += 1;
    }
    else if (zone == JP)
    {
        hour += 2;
    }
    
    //////day
    switch(day)
    {
        case 1:
            LcdPrintStringS(0,0,"SUN");
            break;
        case 2:
            LcdPrintStringS(0,0,"MON");
            break;
        case 3:
            LcdPrintStringS(0,0,"TUE");
            break;
        case 4:
            LcdPrintStringS(0,0,"WED");
            break;
        case 5:
            LcdPrintStringS(0,0,"THU");
            break;
        case 6:
            LcdPrintStringS(0,0,"FRI");
            break;
        case 7:
            LcdPrintStringS(0,0,"SAT");
            break;
    }
    if(hour < 10)
    {
        LcdPrintStringS(0,4,"0");
        LcdPrintNumS(0,5,hour);
    }
    else
        LcdPrintNumS(0,4,hour);
    
    LcdPrintStringS(0,6,":");
    if(minute < 10)
    {
        LcdPrintStringS(0,7,"0");
        LcdPrintNumS(0,8,minute);
    }
    else
        LcdPrintNumS(0,7,minute);

    LcdPrintStringS(0,9,":");
    if(second < 10)
    {
        LcdPrintStringS(0,10,"0");
        LcdPrintNumS(0,11,second);
    }
    else
        LcdPrintNumS(0,10,second);

    switch(bitAlarm)
    {
        case 0:
            LcdPrintStringS(0,13,"OFF");
            break;
        case 1:
            LcdPrintStringS(0,13,"ON ");
            break;
    }
    
    switch(month)
    {
        case 1:
            LcdPrintStringS(1,2,"JAN");
            break;
        case 2:
            LcdPrintStringS(1,2,"FEB");
            break;
        case 3:
            LcdPrintStringS(1,2,"MAR");
            break;
        case 4:
            LcdPrintStringS(1,2,"APR");
            break;
        case 5:
            LcdPrintStringS(1,2,"MAY");
            break;
        case 6:
            LcdPrintStringS(1,2,"JUN");
            break;
        case 7:
            LcdPrintStringS(1,2,"JUL");
            break;
        case 8:
            LcdPrintStringS(1,2,"AUG");
            break;
        case 9:
            LcdPrintStringS(1,2,"SEP");
            break;
        case 10:
            LcdPrintStringS(1,2,"OCT");
            break;
        case 11:
            LcdPrintStringS(1,2,"NOV");
            break;
        case 12:
            LcdPrintStringS(1,2,"DEC");
            break;
    }

    LcdPrintStringS(1,5," ");
    if(date < 10)
    {
        LcdPrintStringS(1,6," ");
        LcdPrintNumS(1,7,date);
    }
    else
        LcdPrintNumS(1,6,date);
    LcdPrintStringS(1,8," ");
    LcdPrintNumS(1,9,20);
    LcdPrintNumS(1,11,year);
    switch (zone)
    {
        case 7:
            LcdPrintStringS(1, 14, "VN");
            break;
        case 8:
            LcdPrintStringS(1, 14, "CN");
            break;
        case 9:
            LcdPrintStringS(1, 14, "JP");
            break;
        default:
        break;
    }
}

void DisplayAlarmTime()
{
    LcdPrintStringS(0,0,"      ALARM     ");
    LcdPrintStringS(1,0,"  ");
    if(hourAlarm < 10)
    {
        LcdPrintStringS(1,2,"0");
        LcdPrintNumS(1,3,hourAlarm);
    }
    else
        LcdPrintNumS(1,2,hourAlarm);
    LcdPrintStringS(1,4,":");
    if(minuteAlarm < 10)
    {
        LcdPrintStringS(1,5,"0");
        LcdPrintNumS(1,6,minuteAlarm);
    }
    else
        LcdPrintNumS(1,5,minuteAlarm);
    LcdPrintStringS(1,7,"   ");
    switch(bitAlarm)
    {
        case 0:
            LcdPrintStringS(1,10,"OFF");
            break;
        case 1:
            LcdPrintStringS(1,10,"ON ");
            break;
    }
    LcdPrintStringS(1,13,"    ");
    
}

void SetUpTime()
{
    switch(statusSetUpTime)
    {
        case INIT_SYSTEM:
            if(isButtonMode() && (bitEnable == ENABLE))
                statusSetUpTime = SET_HOUR;
            break;
        case SET_HOUR:
            bitEnable = DISABLE;
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(0,4,"  ");
            if(isButtonIncrease())
            {
                hour = (hour + 1)%24;
                Write_DS1307(ADDRESS_HOUR,hour);
            }
            if(isButtonDecrease())
            {
                hour = (hour - 1);
                if(hour > 23)
                    hour = 23;
                Write_DS1307(ADDRESS_HOUR,hour);
            }
            if(isButtonMode())
                statusSetUpTime = SET_MINUTE;
            if(isButtonModeHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpTime = INIT_SYSTEM;
            }
            break;
        case SET_MINUTE:
            bitEnable = DISABLE;
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(0,7,"  ");
            if(isButtonIncrease())
            {
                minute = (minute + 1)%60;
                Write_DS1307(ADDRESS_MINUTE,minute);
            }
            if(isButtonDecrease())
            {
                minute = (minute - 1);
                if(minute > 59)
                    minute = 59;
                Write_DS1307(ADDRESS_MINUTE,minute);
            }
            if(isButtonMode())
                statusSetUpTime = SET_DAY;
            if(isButtonModeHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpTime = INIT_SYSTEM;
            }
            break;
        case SET_DAY:
            bitEnable = DISABLE;
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(0,0,"   ");
            if(isButtonIncrease())
            {
                day = day + 1;
                if(day > 7)
                    day = 1;
                Write_DS1307(ADDRESS_DAY,day);
            }
            if(isButtonDecrease())
            {
                day = day - 1;
                if(day > 7)
                    day = 7;
                Write_DS1307(ADDRESS_DAY,day);
            }
            if(isButtonMode())
                statusSetUpTime = SET_DATE;
            if(isButtonModeHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpTime = INIT_SYSTEM;
            }
            break;
        case SET_DATE:
            bitEnable = DISABLE;
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(1,6,"  ");
            if(isButtonIncrease())
            {
                date = date + 1;
                if(date > 31)
                    date = 1;
                Write_DS1307(ADDRESS_DATE,date);
            }
            if(isButtonDecrease())
            {
                date = date - 1;
                if(date < 1)
                    date = 31;
                Write_DS1307(ADDRESS_DATE,date);
            }
            if(isButtonMode())
                statusSetUpTime = SET_MONTH;
            if(isButtonModeHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpTime = INIT_SYSTEM;
            }
            break;
        case SET_MONTH:
            bitEnable = DISABLE;
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(1,2,"   ");
            if(isButtonIncrease())
            {
                month = month + 1;
                if(month > 12)
                    month = 1;
                Write_DS1307(ADDRESS_MONTH,month);
            }
            if(isButtonDecrease())
            {
                month = month - 1;
                if(month < 1)
                    month = 12;
                Write_DS1307(ADDRESS_MONTH,month);
            }
            if(isButtonMode())
                statusSetUpTime = SET_YEAR;
            if(isButtonModeHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpTime = INIT_SYSTEM;
            }
            break;
        case SET_YEAR:
            bitEnable = DISABLE;
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(1,9,"    ");
            if(isButtonIncrease())
            {
                year = year + 1;
                if(year > 99)
                    year = 0;
                Write_DS1307(ADDRESS_YEAR,year);
            }
            if(isButtonDecrease())
            {
                year = year - 1;
                if(year > 99)
                    month = 99;
                Write_DS1307(ADDRESS_YEAR,year);
            }
            if(isButtonMode())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpTime = INIT_SYSTEM;
            }
            if(isButtonModeHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpTime = INIT_SYSTEM;
            }
            break;
        default:
            bitEnable = ENABLE;
            statusSetUpAlarm = INIT_SYSTEM;
            break;

    }
}

void SetUpAlarm()
{
    switch(statusSetUpAlarm)
    {
        case INIT_SYSTEM:
            if(isButtonAlarm() && (bitEnable == ENABLE))
                statusSetUpAlarm = SET_HOUR_ALARM;
            break;
        case SET_HOUR_ALARM:
            bitEnable = DISABLE;
            DisplayAlarmTime();
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(1,2,"  ");
            if(isButtonIncrease())
            {
                hourAlarm = (hourAlarm + 1)%24;
                Write_DS1307(ADDRESS_HOUR_ALARM,hourAlarm);
            }
            if(isButtonDecrease())
            {
                hourAlarm = (hourAlarm - 1);
                if(hourAlarm > 23)
                    hourAlarm = 23;
                Write_DS1307(ADDRESS_HOUR_ALARM,hourAlarm);
            }
            if(isButtonAlarm())
                statusSetUpAlarm = SET_MINUTE_ALARM;
            if(isButtonAlarmHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpAlarm = INIT_SYSTEM;
            }
            break;
        case SET_MINUTE_ALARM:
            bitEnable = DISABLE;
            DisplayAlarmTime();
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(1,5,"  ");
            if(isButtonIncrease())
            {
                minuteAlarm = (minuteAlarm + 1)%60;
                Write_DS1307(ADDRESS_MINUTE_ALARM,minuteAlarm);
            }
            if(isButtonDecrease())
            {
                minuteAlarm = (minuteAlarm - 1);
                if(minuteAlarm > 59)
                    minuteAlarm = 59;
                Write_DS1307(ADDRESS_MINUTE_ALARM,minuteAlarm);
            }
            if(isButtonAlarm())
                statusSetUpAlarm = BIT_ALARM;
            if(isButtonAlarmHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpAlarm = INIT_SYSTEM;
            }
            break;
        case BIT_ALARM:
            bitEnable = DISABLE;
            DisplayAlarmTime();
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink > 15)
                LcdPrintStringS(1,10,"   ");
            if(isButtonIncrease())
            {
                bitAlarm = (bitAlarm + 1)%2;
                Write_DS1307(ADDRESS_BIT_ALARM,bitAlarm);
            }
            if(isButtonDecrease())
            {
                bitAlarm = (bitAlarm - 1);
                if(bitAlarm > 1)
                    bitAlarm = 1;
                Write_DS1307(ADDRESS_BIT_ALARM,bitAlarm);
            }
            if(isButtonAlarm())
            {
                LcdClearS();
                statusSetUpAlarm = INIT_SYSTEM;
                bitEnable = ENABLE;
            }
            if(isButtonAlarmHold())
            {
                LcdClearS();
                bitEnable = ENABLE;
                statusSetUpAlarm = INIT_SYSTEM;
            }
            break;
        default:
            break;
    }
}


unsigned char CompareTime()
{
    if((hour == hourAlarm) && (minute == minuteAlarm) && (second == 0) && (bitAlarm == ON) && (bitEnable == ENABLE))
        return 1;
    else
        return 0;
}

void Alarm()
{
    static unsigned char timeBlink = 0;
    switch(statusAlarm)
    {
        case INIT_SYSTEM:
            statusAlarm = COMPARE;
            break;
        case COMPARE:
            if(CompareTime())
            {
                flagAlarm = 1;
                Write_DS1307(ADDRESS_FLAG_ALARM,flagAlarm);
            }
            if(flagAlarm)
                statusAlarm = ALARM;
            break;
        case ALARM:
            /// bao chuong
            bitEnable = DISABLE;
            timeBlink = (timeBlink + 1)%20;
            if(timeBlink < 10)
            {
                LcdClearS();
            }
            timeAlarm ++;
            if(timeAlarm > 400)
            {
                bitEnable = ENABLE;
                flagAlarm = 0;
                Write_DS1307(ADDRESS_FLAG_ALARM,flagAlarm);
                timeAlarm = 0;
                LcdClearS();
                statusAlarm = INIT_SYSTEM;
            }
            break;
    }
}
void DisplayStopWatch()
{
    LcdPrintStringS(0,0,"   STOPWATCH    ");
    LcdPrintStringS(1,0,"  ");
    if(minuteStop < 10)
    {
        LcdPrintStringS(1,2,"0");
        LcdPrintNumS(1,3,minuteStop);
    }
    else
        LcdPrintNumS(1,2,minuteStop);
    LcdPrintStringS(1,4,":");
    if(secondStop < 10)
    {
        LcdPrintStringS(1,5,"0");
        LcdPrintNumS(1,6,secondStop);
    }
    else
        LcdPrintNumS(1,5,secondStop);
    LcdPrintStringS(1,7,":");
    if(centisecondStop < 10)
    {
        LcdPrintStringS(1,8,"0");
        LcdPrintNumS(1,9,centisecondStop);
    }
    else
        LcdPrintNumS(1,8,centisecondStop);
    LcdPrintStringS(1,10,"  ");
    switch(bitStop)
    {
        case 0:
            LcdPrintStringS(1,12,"OFF");
            break;
        case 1:
            LcdPrintStringS(1,12,"ON ");
            break;
    }
    LcdPrintStringS(1,15,"  ");
    
}
void DisplayCountDown()
{
    LcdPrintStringS(0,0,"   COUNTDOWN    ");
    LcdPrintStringS(1,0,"  ");
    if(hourCount < 10)
    {
        LcdPrintStringS(1,2,"0");
        LcdPrintNumS(1,3,hourCount);
    }
    else
        LcdPrintNumS(1,2,hourCount);
    LcdPrintStringS(1,4,":");
    if(minuteCount < 10)
    {
        LcdPrintStringS(1,5,"0");
        LcdPrintNumS(1,6,minuteCount);
    }
    else
        LcdPrintNumS(1,5,minuteCount);
    LcdPrintStringS(1,7,":");
    if(secondCount < 10)
    {
        LcdPrintStringS(1,8,"0");
        LcdPrintNumS(1,9,secondCount);
    }
    else
        LcdPrintNumS(1,8,secondCount);
    LcdPrintStringS(1,10,"  ");
    switch(bitCount)
    {
        case 0:
            LcdPrintStringS(1,12,"OFF");
            break;
        case 1:
            LcdPrintStringS(1,12,"ON ");
            break;
    }
    LcdPrintStringS(1,15,"  ");
}
void DisplayFocus()
{
    LcdPrintStringS(0,0,"      FOCUS     ");
    LcdPrintStringS(1,0,"  ");
    if(hourFocus < 10)
    {
        LcdPrintStringS(1,2,"0");
        LcdPrintNumS(1,3,hourFocus);
    }
    else
        LcdPrintNumS(1,2,hourFocus);
    LcdPrintStringS(1,4,":");
    if(minuteFocus < 10)
    {
        LcdPrintStringS(1,5,"0");
        LcdPrintNumS(1,6,minuteFocus);
    }
    else
        LcdPrintNumS(1,5,minuteFocus);
    LcdPrintStringS(1,7,":");
    if(secondFocus < 10)
    {
        LcdPrintStringS(1,8,"0");
        LcdPrintNumS(1,9,secondFocus);
    }
    else
        LcdPrintNumS(1,8,secondFocus);
    LcdPrintStringS(1,10,"  ");
    switch(bitFocus)
    {
        case 0:
            LcdPrintStringS(1,12,"OFF");
            break;
        case 1:
            LcdPrintStringS(1,12,"ON ");
            break;
    }
    LcdPrintStringS(1,15,"  ");
}

void setState(unsigned char theState)
{
    state = theState;
}