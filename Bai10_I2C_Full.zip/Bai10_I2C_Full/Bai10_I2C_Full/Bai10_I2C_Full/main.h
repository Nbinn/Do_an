#ifndef	_MAIN_H_
#define _MAIN_H_

signed char getZone();
void setZone(signed char timeZone);
void setDone(signed char timeDone);
void setState(unsigned char theState);

#endif