
#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"
#define     VN          7
#define     CN          8 
#define     JP          9
#define     WAIT        0

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6

unsigned char timeZone = WAIT;
unsigned char secondZone = 0,minuteZone = 0;
char hourZone = 0;
unsigned char dayZone = 0;
signed char dateZone = 0,monthZone = 0,yearZone = 0;
signed char temp;
void readTime(void){
    secondZone = Read_DS1307(ADDRESS_SECOND);
    minuteZone = Read_DS1307(ADDRESS_MINUTE);
    hourZone = Read_DS1307(ADDRESS_HOUR);
    dayZone = Read_DS1307(ADDRESS_DAY);
    dateZone = Read_DS1307(ADDRESS_DATE);
    monthZone = Read_DS1307(ADDRESS_MONTH);
    yearZone = Read_DS1307(ADDRESS_YEAR);
}
void writeTime(void){
    Write_DS1307(ADDRESS_SECOND, secondZone);
    Write_DS1307(ADDRESS_MINUTE, minuteZone);
    Write_DS1307(ADDRESS_HOUR, hourZone);
    Write_DS1307(ADDRESS_DAY, dayZone);
    Write_DS1307(ADDRESS_DATE, dateZone);
    Write_DS1307(ADDRESS_MONTH, monthZone);
    Write_DS1307(ADDRESS_YEAR, yearZone);
}

void selectTimeZone(void){
    LcdPrintStringS(0,0,"1.VIETNAM       ");
    LcdPrintStringS(1,0,"2.CHINA  3.JAPAN");
    temp = getZone();
    switch (timeZone){
        case WAIT:
            if(isButton1()){
                timeZone = VN;
            }
            else if(isButton2()){
                timeZone = CN;
            }
            else if(isButton3()){
                timeZone = JP;
            }
            break;
        case VN:
            readTime();
            hourZone += (VN-temp);
            writeTime();
            setZone(VN);
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            break;
        case CN:
            readTime();
            hourZone += (CN-temp);
            writeTime();
            setZone(CN);
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            break;
        case JP:
            readTime();
            hourZone += (JP-temp);
            writeTime();
            setZone(JP);
            setDone(0);
            timeZone = WAIT; 
            setState(CLOCK);
            break;             
    }
}
