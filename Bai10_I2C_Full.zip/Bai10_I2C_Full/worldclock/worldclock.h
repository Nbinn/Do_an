/* 
 * File:   worldclock.h
 * Author: Tho Nhan
 *
 * Created on December 13, 2021, 3:12 PM
 */

#ifndef WORLDCLOCK_H
#define	WORLDCLOCK_H

    
void readTime(void);
void writeTime(void);
void selectTimeZone(void);


#endif	/* WORLDCLOCK_H */

