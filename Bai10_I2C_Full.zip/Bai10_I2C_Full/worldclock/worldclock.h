/* 
 * File:   worldclock.h
 * Author: Tho Nhan
 *
 * Created on December 13, 2021, 3:12 PM
 */

#ifndef WORLDCLOCK_H
#define	WORLDCLOCK_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <p18f4620.h>
#include "timer\timer.h"
#include "interrupt\interrupt.h"
#include "button_matrix\button.h"
#include "lcd\lcd.h"
#include "i2c\i2c.h"

void readTime(void);
void writeTime(void);
void selectTimeZone(void);

#ifdef	__cplusplus
}
#endif


#endif	/* WORLDCLOCK_H */

