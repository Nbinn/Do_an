#include "worldclock.h"
#define     VN          7
#define     CN          8 
#define     JP          9
#define     WAIT        0
/*
unsigned char timeZone = WAIT;
unsigned char done = 0;
unsigned char secondZone = 0,minuteZone = 0;
char hourZone = 0;
unsigned char dayZone = 0;
signed char dateZone = 0,monthZone = 0,yearZone = 0;
signed char temp;
void readTime(){
    secondZone = Read_DS1307(ADDRESS_SECOND);
    minuteZone = Read_DS1307(ADDRESS_MINUTE);
    hourZone = Read_DS1307(ADDRESS_HOUR);
    dayZone = Read_DS1307(ADDRESS_DAY);
    dateZone = Read_DS1307(ADDRESS_DATE);
    monthZone = Read_DS1307(ADDRESS_MONTH);
    yearZone = Read_DS1307(ADDRESS_YEAR);
}
void writeTime(){
    Write_DS1307(ADDRESS_SECOND, secondZone);
    Write_DS1307(ADDRESS_MINUTE, minuteZone);
    Write_DS1307(ADDRESS_HOUR, hourZone);
    Write_DS1307(ADDRESS_DAY, dayZone);
    Write_DS1307(ADDRESS_DATE, dateZone);
    Write_DS1307(ADDRESS_MONTH, monthZone);
    Write_DS1307(ADDRESS_YEAR, yearZone);
}

void selectTimeZone(){
    LcdPrintStringS(0,0,"1.VIETNAM       ");
    LcdPrintStringS(1,0,"2.CHINA  3.JAPAN");
    temp = getZone();
    switch (timeZone){
        case WAIT:
            if(isButton1()){
                timeZone = VN;
            }
            else if(isButton2()){
                timeZone = CN;
            }
            else if(isButton3()){
                timeZone = JP;
            }
            break;
        case VN:
            readTime();
            hour += (VN-temp);
            writeTime();
            setZone(VN);
            done = 1;
            break;
        case CN:
            readTime();
            hour += (CN-temp);
            writeTime();
            setZone(CN);
            done = 1;
            break;
        case JP:
            readTime();
            hour += (JP-temp);
            writeTime();
            setZone(JP);
            done = 1;
            break;             
    }
}
unsigned char isDone(){
    return done;
}
void setDone(unsigned char temp){
    done = tmp;
}*/