#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"
#include "../setting/setting.h"

#define     ADDRESS_HOUR_ALARM      0x10
#define     ADDRESS_MINUTE_ALARM    0x11
#define     ADDRESS_BIT_ALARM       0x12
#define     ADDRESS_FLAG_ALARM      0x13

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6
#define     SETTINGS       7

#define     HOURALARM      1
#define     MINUTEALARM    2
#define     SECONDALARM    3
#define     ALARM          4
#define     WAIT          30

unsigned char hAlarm = 0, minAlarm = 0, secAlarm = 0;
unsigned char alarm = WAIT;
unsigned char modeAlarm = 0;
unsigned char firstAlarm = 0, secondAlarm = 0,blinkAlarm = 0;
unsigned char compareTimeAlarm(){
    unsigned char second = Read_DS1307(ADDRESS_SECOND);
    unsigned char minute = Read_DS1307(ADDRESS_MINUTE);
    unsigned char hour = Read_DS1307(ADDRESS_HOUR);
    if(hAlarm == hour && minAlarm == minute && secAlarm == second){
        return 1;
    }
    else return 0;
}
void setAlarm(){
    switch (alarm){
        case ALARM:
            if(compareTimeAlarm()){
                LcdClearS();
                LcdPrintStringS(0,0,"   Alarmmmmm!   ");
            }
            break;
        case WAIT:
            alarm = HOURALARM;
            break;
        case SECONDALARM:
            if (isButtonHash())
            {
                setState(SELECT);
                alarm = WAIT;
            }
            if(!modeAlarm){
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,8,"_");
                }
                buttonSetting(&firstAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,8,firstAlarm);
                }
            }
            else{
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,9,"_");
                }
                buttonSetting(&secondAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    secAlarm = firstAlarm*10+secondAlarm;
                    firstAlarm = 0;
                    secondAlarm = 0;
                    LcdPrintNumS(1,9,secAlarm%10);
                    alarm = ALARM;
                }
            }
            break;
        case MINUTEALARM:
            if (isButtonHash())
            {
                setState(SELECT);
                alarm = WAIT;
            }
            if(!modeAlarm){
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,5,"_");
                }
                buttonSetting(&firstAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,5,firstAlarm);
                }
            }
            else{
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,6,"_");
                }
                buttonSetting(&secondAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    minAlarm = firstAlarm*10+secondAlarm;
                    firstAlarm = 0;
                    secondAlarm = 0;
                    LcdPrintNumS(1,6,minAlarm%10);
                    alarm = SECONDALARM;
                }
            }
            break;
        case HOURALARM:
            if (isButtonHash())
            {
                setState(SELECT);
                alarm = WAIT;
            }
            if(!modeAlarm){
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,2,"_");
                }
                buttonSetting(&firstAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,2,firstAlarm);
                }
            }
            else{
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,3,"_");
                }
                buttonSetting(&secondAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    hAlarm = firstAlarm*10+secondAlarm;
                    firstAlarm = 0;
                    secondAlarm = 0;
                    LcdPrintNumS(1,3,hAlarm%10);
                    alarm = SECONDALARM;
                }
            }
            break;
    }
}
