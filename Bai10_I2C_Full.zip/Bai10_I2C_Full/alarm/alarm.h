/* 
 * File:   alarm.h
 * Author: Tho Nhan
 *
 * Created on December 15, 2021, 10:47 PM
 */

#ifndef ALARM_H
#define	ALARM_H

#ifdef	__cplusplus
extern "C" {
#endif

unsigned char compareTimeAlarm();


#ifdef	__cplusplus
}
#endif

#endif	/* ALARM_H */

