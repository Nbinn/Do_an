#ifndef _BUTTON_H_
#define _BUTTON_H_

#include <p18f4620.h>

#define PORT_BUTTON		PORTC
#define TRIS_BUTTON		TRISC
#define	MAX_COL			4
#define MAX_ROW			4

extern unsigned int key_code[];

void init_key_matrix(void);
void init_key_matrix_with_uart_i2c(void);
void scan_key_matrix(void);
void scan_key_matrix_with_uart_i2c(void);
void button_process(void);
void button_delay_ms(int value);
void scan_key_matrix_demo(void);

unsigned char isButtonMode(void);
unsigned char isButtonAlarm(void);
unsigned char isButtonModeHold(void);
unsigned char isButtonAlarmHold(void);
unsigned char isButtonIncrease(void);
unsigned char isButtonDecrease(void);
unsigned char isButton1(void);
unsigned char isButton2(void);
unsigned char isButton3(void);
unsigned char isButtonA(void);
unsigned char isButton4(void);
unsigned char isButton5(void);
unsigned char isButton6(void);
unsigned char isButtonB(void);
unsigned char isButton7(void);
unsigned char isButton8(void);
unsigned char isButton9(void);
unsigned char isButtonC(void);
unsigned char isButtonAsterisk(void);
unsigned char isButton0(void);
unsigned char isButtonHash(void);
unsigned char isButtonD(void);

#endif