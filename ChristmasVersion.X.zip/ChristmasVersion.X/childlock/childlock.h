/* 
 * File:   childlock.h
 * Author: Tho Nhan
 *
 * Created on December 24, 2021, 10:31 AM
 */

#ifndef CHILDLOCK_H
#define	CHILDLOCK_H

void childLock(void);
unsigned char isChildLock(void);

#endif	/* CHILDLOCK_H */

