#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"
#include "../timer/timer.h"

#define     WAIT    30
#define     SELECT  0
#define     CLOCK   1
#define     LOCK    1

#define     ENG     0
#define     FR      1
#define     GE      21
#define     VN      7
unsigned char lock = WAIT;
unsigned char secondLock = 0;
unsigned char keyLock = 0;

unsigned char isChildLock(void)
{
    if (lock == LOCK)
        return 1;
    else
        return 0;
}

void childLock(){
    if (isButtonHash())
        setState(SELECT);
    switch (lock){
        case WAIT:
            switch (getLang())
            {
                default:
                    LcdPrintStringS(0,0,"   CHILD LOCK   ");
                    LcdPrintStringS(1,0,"  Hit 0 to lock ");
                    break;
                case FR:
                    LcdPrintStringS(0,0,"SECURITE ENFANTS");
                    LcdPrintStringS(1,0,"0.VERROUILLER");
                    break;
                case GE:
                    LcdPrintStringS(0,0,"KINDERSISCHERUNG");
                    LcdPrintStringS(1,0,"0.SERRURE");
                    break;              
                case VN:
                    LcdPrintStringS(0,0,"  KHOA TRE EM.  ");
                    LcdPrintStringS(1,0," NHAN 0 DE KHOA ");
                    break;                         
            }
            if(isButton0())
            {
                lock = LOCK;
                setState(CLOCK);
            }
            break;
        case LOCK:
            secondLock = Read_DS1307(ADDRESS_SECOND);
            LcdClearS();
            
            switch (getLang())
            {
                default:
                    LcdPrintStringS(0,0,"   CHILDLOCKED   ");
                    LcdPrintStringS(1,0,"Hit ");
                    LcdPrintNumS(1,4,secondLock%10);                           
                    LcdPrintStringS(1,5," to unlock.");                    
                    break;
                case FR:
                    LcdPrintStringS(0,0,"SECURITE ENFANTS");
                    LcdPrintNumS(1,0,secondLock%10);                           
                    LcdPrintStringS(1,1,".DEVERROUILLER");                    
                    break;   
                case GE:
                    LcdPrintStringS(0,0,"KINDERSISCHERUNG");
                    LcdPrintNumS(1,0,secondLock%10);                           
                    LcdPrintStringS(1,1,".FREISCHALTEN");                    
                    break;  
                case VN:
                    LcdPrintStringS(0,0,"  KHOA TRE EM.  ");
                    LcdPrintStringS(1,0,"Bam ");
                    LcdPrintNumS(1,4,secondLock%10);                           
                    LcdPrintStringS(1,5," de mo khoa");                   
                    break;                     
            }

            

            buttonSetting(&keyLock);                                                                                        
            if(getDone()){
                                                                                      
                if(keyLock == secondLock%10){
                    setState(CLOCK);
                    lock = WAIT;
                    keyLock = 999;
                }
            }
            break;
    }
}
