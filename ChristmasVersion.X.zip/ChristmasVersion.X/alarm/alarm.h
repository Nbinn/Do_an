/* 
 * File:   alarm.h
 * Author: Tho Nhan
 *
 * Created on December 15, 2021, 10:47 PM
 */


unsigned char compareTimeAlarm();
void setAlarm(void);

void runAlarm(void);


