#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"
#include "../timer/timer.h"
#define     ADDRESS_YEAR_COUNT_DOWN      0x1A
#define     ADDRESS_MONTH_COUNT_DOWN     0x1B
#define     ADDRESS_DATE_COUNT_DOWN      0x1C
#define     ADDRESS_HOUR_COUNT_DOWN      0x1D
#define     ADDRESS_MINUTE_COUNT_DOWN    0x1E
#define     ADDRESS_SECOND_COUNT_DOWN    0x1F

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6
#define     SETTINGS       7

#define     HOURCOUNTDOWN      1
#define     MINUTECOUNTDOWN    2
#define     SECONDCOUNTDOWN    3
#define     COUNT              4
#define     WAIT               30
#define     ERROR              31

#define     ENG            0
#define     FR             1
#define     VN             7

unsigned char hourCountDown = 0, minuteCountDown = 0, secCountDown = 0;
unsigned char hourStart = 0, minuteStart = 0, secondStart = 0;
unsigned char yearStart = 0, monthStart = 0, dateStart = 0;
unsigned char hourEnd = 0,minuteEnd = 0,secondEnd = 0;
unsigned char yearEnd = 0, monthEnd = 0, dateEnd = 0;
unsigned char countDown = WAIT;
unsigned char modeCountDown = 0;
unsigned char firstCountDown = 0, secondCountDown = 0,blinkCountDown = 0;
unsigned char tempCount = 0;
unsigned int errorCheckCountDown(void)
{
    if (minuteCountDown > 59)
        return 1;
    if (secCountDown > 59)
        return 1;
    return 0;
}
void calculate(){
    secondEnd = secCountDown + secondStart;
    if(secondEnd > 59){
        secondEnd -= 59;
        minuteEnd += 1;
    }
    minuteEnd += minuteCountDown + minuteStart;
    if(minuteEnd > 59){
        minuteEnd -=59;
        hourEnd += 1;
    }
    if(hourCountDown > 23){
        tempCount = hourCountDown/24;
        hourCountDown %= 24;
        dateEnd = dateStart + tempCount;
    }
    if(monthStart==1 || monthStart==3 || monthStart==5 || monthStart==7 || monthStart== 8|| monthStart==10 || monthStart==12){
        if(dateEnd > 31){
            dateEnd -= 31;
            monthEnd+=1;
        }
    }
    if(monthStart==4 || monthStart==6 || monthStart==9 || monthStart==11){
        if(dateStart > 30){
            dateStart -= 30;
             monthEnd += 1;
        }

    }
    if(monthStart == 2 && (yearStart%4 == 0)){
        if(dateEnd > 29){
            dateEnd -= 29;
            monthEnd += 1;
        }
  
    }
    else{
        if(dateEnd > 28){
            dateEnd -= 28;
            monthEnd += 1;
        }
    }
    if(monthEnd > 12){
        monthEnd = 1;
        yearEnd = yearStart + 1;
    }
    Write_DS1307(ADDRESS_YEAR_COUNT_DOWN,yearEnd);
    Write_DS1307(ADDRESS_MONTH_COUNT_DOWN,monthEnd);
    Write_DS1307(ADDRESS_DATE_COUNT_DOWN,dateEnd);
    Write_DS1307(ADDRESS_HOUR_COUNT_DOWN,hourEnd);
    Write_DS1307(ADDRESS_MINUTE_COUNT_DOWN,minuteEnd);
    Write_DS1307(ADDRESS_SECOND_COUNT_DOWN,secondEnd);
}
void showCountDown(){
    unsigned char secondNow = Read_DS1307(ADDRESS_SECOND);
    unsigned char minuteNow = Read_DS1307(ADDRESS_MINUTE);
    unsigned char hourNow = Read_DS1307(ADDRESS_SECOND);
    unsigned char dateNow = Read_DS1307(ADDRESS_DATE);
    unsigned char monthNow = Read_DS1307(ADDRESS_MONTH);
    unsigned char yearNow = Read_DS1307(ADDRESS_YEAR);
    unsigned char hourShow = 0, minuteShow = 0, secondShow = 0;
    
    unsigned char second = Read_DS1307(ADDRESS_SECOND_COUNT_DOWN);
    unsigned char minute = Read_DS1307(ADDRESS_MINUTE_COUNT_DOWN);
    unsigned char hour = Read_DS1307(ADDRESS_HOUR_COUNT_DOWN);
    unsigned char date = Read_DS1307(ADDRESS_DATE_COUNT_DOWN);
    unsigned char month = Read_DS1307(ADDRESS_MONTH_COUNT_DOWN);
    unsigned char year = Read_DS1307(ADDRESS_YEAR_COUNT_DOWN);
   if(year > yearNow){
       month = 13;
   } 
    if(month > monthNow){
        if(monthNow == 1 || monthNow == 2 || monthNow == 4 || monthNow == 6 || monthNow == 8 || monthNow == 9 || monthNow == 11){
            date += 31;
        }
        else if(monthNow == 5 || monthNow == 7 || monthNow == 10 || monthNow == 12){
            date +=30;
        }
        else if(monthNow == 3 || (year%4 == 0)){
            date +=29;
        }
        else date += 28;
    }
    if(date > dateNow){
        hour += (date-dateNow)*60;
    }
    if(hour > hourNow){
        hourShow = hour - hourNow;
    }
    else{
        hourShow = 0;
    }
    if(second < secondNow){
        second += 60;
        minute -= 1;
    }
    if(minute < minuteNow){
        hourShow -= 1;
        minute += 60;
    }
    secondShow = second - secondNow;
    minuteShow = minute - minuteNow;
   
    LcdPrintStringS(0,0,"   COUNTDOWN    ");
            LcdPrintStringS(1,0,"  ");
            if(hourShow < 10)
            {
                LcdPrintStringS(1,4,"0");
                LcdPrintNumS(1,5,hourShow);
            }
            else
                LcdPrintNumS(1,4,hourShow);
            LcdPrintStringS(1,6,":");
            if(minuteShow < 10)
            {
                LcdPrintStringS(1,7,"0");
                LcdPrintNumS(1,8,minuteShow);
            }
            else
                LcdPrintNumS(1,7,minuteShow);
            LcdPrintStringS(1,9,":");
            if(secondShow < 10)
            {
                LcdPrintStringS(1,10,"0");
                LcdPrintNumS(1,11,secondShow);
            }
            else
                LcdPrintNumS(1,10,secondShow);
            LcdPrintStringS(1,12,"     ");
}
void setCountDown(void){
    switch (countDown){
        case WAIT:
            
            LcdClearS();
            LcdPrintStringS(0,0,"   COUNTDOWN    ");
            LcdPrintStringS(1,0,"  ");
            if(hourCountDown < 10)
            {
                LcdPrintStringS(1,4,"0");
                LcdPrintNumS(1,5,hourCountDown);
            }
            else
                LcdPrintNumS(1,4,hourCountDown);
            LcdPrintStringS(1,6,":");
            if(minuteCountDown < 10)
            {
                LcdPrintStringS(1,7,"0");
                LcdPrintNumS(1,8,minuteCountDown);
            }
            else
                LcdPrintNumS(1,7,minuteCountDown);
            LcdPrintStringS(1,9,":");
            if(secCountDown < 10)
            {
                LcdPrintStringS(1,10,"0");
                LcdPrintNumS(1,11,secCountDown);
            }
            else
                LcdPrintNumS(1,10,secCountDown);
            LcdPrintStringS(1,12,"     ");
            countDown = HOURCOUNTDOWN;
            break;
        case SECONDCOUNTDOWN:
            if (isButtonHash())
            {
                setState(SELECT);
                countDown = WAIT;
            }
            if(modeCountDown == 0){
                blinkCountDown = (blinkCountDown+1)%20;
                if(blinkCountDown > 15){
                    LcdPrintStringS(1,10,"_");
                }
                buttonSetting(&firstCountDown);
                if(getDone()){
                    modeCountDown = 1;
                    setDone(0);
                    LcdPrintNumS(1,10,firstCountDown);
                }
            }
            else if(modeCountDown == 1){
                blinkCountDown = (blinkCountDown+1)%20;
                if(blinkCountDown > 15){
                    LcdPrintStringS(1,11,"_");
                }
                buttonSetting(&secondCountDown);
                if(getDone()){
                    modeCountDown = 2;
                    setDone(0);
                    secCountDown = firstCountDown*10+secondCountDown;
                    firstCountDown = 0;
                    secondCountDown = 0;
                    LcdPrintNumS(1,11,secCountDown%10);
                    
                }
            }
            else if(modeCountDown == 2){
                if(isButtonAsterisk()){   
                    if(!errorCheckCountDown()){
                        calculate();
                        countDown = COUNT;
                    }
                }
            }
            break;
        case MINUTECOUNTDOWN:
            if (isButtonHash())
            {
                setState(SELECT);
                countDown = WAIT;
            }
            if(!modeCountDown){
                blinkCountDown = (blinkCountDown+1)%20;
                if(blinkCountDown > 15){
                    LcdPrintStringS(1,7,"_");
                }
                buttonSetting(&firstCountDown);
                if(getDone()){
                    modeCountDown ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,7,firstCountDown);
                }
            }
            else{
                blinkCountDown = (blinkCountDown+1)%20;
                if(blinkCountDown > 15){
                    LcdPrintStringS(1,8,"_");
                }
                buttonSetting(&secondCountDown);
                if(getDone()){
                    modeCountDown ^= 0x01;
                    setDone(0);
                    minuteCountDown = firstCountDown*10+secondCountDown;
                    firstCountDown = 0;
                    secondCountDown = 0;
                    LcdPrintNumS(1,8,minuteCountDown%10);
                    countDown = SECONDCOUNTDOWN;
                }
            }
            break;
        case HOURCOUNTDOWN:
            if (isButtonHash())
            {
                setState(SELECT);
                countDown = WAIT;
            }
            if(!modeCountDown){
                blinkCountDown = (blinkCountDown+1)%20;
                if(blinkCountDown > 15){
                    LcdPrintStringS(1,4,"_");
                }
                buttonSetting(&firstCountDown);
                if(getDone()){
                    modeCountDown ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,4,firstCountDown);
                }
            }
            else{
                blinkCountDown = (blinkCountDown+1)%20;
                if(blinkCountDown > 15){
                    LcdPrintStringS(1,5,"_");
                }
                buttonSetting(&secondCountDown);
                if(getDone()){
                    modeCountDown ^= 0x01;
                    setDone(0);
                    hourCountDown = firstCountDown*10+secondCountDown;
                    firstCountDown = 0;
                    secondCountDown = 0;
                    LcdPrintNumS(1,5,hourCountDown%10);
                    countDown = MINUTECOUNTDOWN;
                }
            }
            break;
        case ERROR:
            LcdClearS();
            switch (getLang())
            {
                default:
                    LcdPrintStringS(0,4,"ERROR(S)");
                    LcdPrintStringS(1,0,"  Please hit 0.  ");
                    break;
                case VN:
                    LcdPrintStringS(0,0,"  DA XAY RA LOI  ");
                    LcdPrintStringS(1,0," Hay nhan nut 0 ");
                    break;
                case FR:
                    LcdPrintStringS(0,0,"     ERREUR     ");
                    LcdPrintStringS(1,0," Appuyez sur 0 ");
                    break;
            }
            if (isButton0())
            {
                //setState(CLOCK);
                countDown = WAIT;
            }
            break;
        case COUNT:
            
            showCountDown();
            break;
            
    }
}
