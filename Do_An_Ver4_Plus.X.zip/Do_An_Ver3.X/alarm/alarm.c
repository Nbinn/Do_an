#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"

#define     ADDRESS_HOUR_ALARM      0x10
#define     ADDRESS_MINUTE_ALARM    0x11
#define     ADDRESS_SECOND_ALARM    0x12

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6
#define     SETTINGS       7

#define     HOURALARM      1
#define     MINUTEALARM    2
#define     SECONDALARM    3
#define     WAIT          30
#define     ERROR         31

#define     ENG            0
#define     FR             1
#define     VN             7

unsigned char hAlarm = 0, minAlarm = 0, secAlarm = 0;
unsigned char alarm = WAIT;
unsigned char modeAlarm = 0;
unsigned char firstAlarm = 0, secondAlarm = 0,blinkAlarm = 0;

unsigned char compareTimeAlarm(){
    unsigned char second = Read_DS1307(ADDRESS_SECOND);
    unsigned char minute = Read_DS1307(ADDRESS_MINUTE);
    unsigned char hour = Read_DS1307(ADDRESS_HOUR);
    if(hAlarm == hour && minAlarm == minute && secAlarm == second){
        return 1;
    }
    else return 0;
}

unsigned int errorCheckAlarm(void)
{
    if (hAlarm > 23)
        return 1;
    if (minAlarm > 59)
        return 1;
    if (secAlarm > 59)
        return 1;
    return 0;
}

void runAlarm(void)
{
    LcdClearS();
    if (getLang() == 0)
        LcdPrintStringS(0,0,"   Alarmmmmm!   ");
    else if (getLang() == VN)
        LcdPrintStringS(0,0,"  Bao thucccc!  ");
    else if (getLang() == FR)
        LcdPrintStringS(0,0,"   Alarmeeee!   ");
   
}
void setAlarm(void){
    switch (alarm){
        case WAIT:
            hAlarm = Read_DS1307(ADDRESS_HOUR_ALARM);
            minAlarm = Read_DS1307(ADDRESS_MINUTE_ALARM);
            secAlarm = Read_DS1307(ADDRESS_SECOND_ALARM);
            LcdClearS();
            switch (getLang())
            {
                case FR:
                    LcdPrintStringS(0,0,"   PARAMETRES   ");
                    break;
                case VN:
                    LcdPrintStringS(0,0,"CAI DAT BAO THUC");
                    break;
                default:
                    LcdPrintStringS(0,0," ALARM SETTING: ");
                    break;
            }
            //LcdPrintStringS(0,0," ALARM SETTING: ");
            if (hAlarm >= 10)
                LcdPrintNumS(1,4,hAlarm);
            else
            {
                LcdPrintNumS(1,4,0);
                LcdPrintNumS(1,5,hAlarm);
            }
            LcdPrintStringS(1,6,":");
            if (minAlarm >= 10)
                LcdPrintNumS(1,7,minAlarm);
            else
            {
                LcdPrintNumS(1,7,0);
                LcdPrintNumS(1,8,minAlarm);  
            }
            LcdPrintStringS(1,9,":");
            if (secAlarm >= 10)
                LcdPrintNumS(1,10,secAlarm);
            else
            {
                LcdPrintNumS(1,10,0);
                LcdPrintNumS(1,11,secAlarm);
            }
            alarm = HOURALARM;
            break;
        case SECONDALARM:
            if (isButtonHash())
            {
                setState(SELECT);
                alarm = WAIT;
            }
            if(modeAlarm == 0){
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,10,"_");
                }
                buttonSetting(&firstAlarm);
                if(getDone()){
                    modeAlarm = 1;
                    setDone(0);
                    LcdPrintNumS(1,10,firstAlarm);
                }
            }
            else if(modeAlarm == 1){
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,11,"_");
                }
                buttonSetting(&secondAlarm);
                if(getDone()){
                    modeAlarm = 2;
                    setDone(0);
                    secAlarm = firstAlarm*10+secondAlarm;
                    firstAlarm = 0;
                    secondAlarm = 0;
                    LcdPrintNumS(1,11,secAlarm%10);
                    
                }
            }
            else if(modeAlarm == 2){
                if(isButtonAsterisk()){
                    modeAlarm = 0;
                    if (!errorCheckAlarm())
                    {
                        Write_DS1307(ADDRESS_HOUR_ALARM, hAlarm);
                        Write_DS1307(ADDRESS_MINUTE_ALARM, minAlarm);
                        Write_DS1307(ADDRESS_SECOND_ALARM, secAlarm);
                        alarm = WAIT;
                        setState(CLOCK);
                        setAlarmOn(1);
                    }
                    else
                        alarm = ERROR;
                }
            }
            break;
        case MINUTEALARM:
            if (isButtonHash())
            {
                setState(SELECT);
                alarm = WAIT;
            }
            if(!modeAlarm){
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,7,"_");
                }
                buttonSetting(&firstAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,7,firstAlarm);
                }
            }
            else{
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,8,"_");
                }
                buttonSetting(&secondAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    minAlarm = firstAlarm*10+secondAlarm;
                    firstAlarm = 0;
                    secondAlarm = 0;
                    LcdPrintNumS(1,8,minAlarm%10);
                    alarm = SECONDALARM;
                }
            }
            break;
        case HOURALARM:
            if (isButtonHash())
            {
                setState(SELECT);
                alarm = WAIT;
            }
            if(!modeAlarm){
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,4,"_");
                }
                buttonSetting(&firstAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,4,firstAlarm);
                }
            }
            else{
                blinkAlarm = (blinkAlarm+1)%20;
                if(blinkAlarm > 15){
                    LcdPrintStringS(1,5,"_");
                }
                buttonSetting(&secondAlarm);
                if(getDone()){
                    modeAlarm ^= 0x01;
                    setDone(0);
                    hAlarm = firstAlarm*10+secondAlarm;
                    firstAlarm = 0;
                    secondAlarm = 0;
                    LcdPrintNumS(1,5,hAlarm%10);
                    alarm = MINUTEALARM;
                }
            }
            break;
        case ERROR:
            LcdClearS();
            switch (getLang())
            {
                default:
                    LcdPrintStringS(0,4,"ERROR(S)");
                    LcdPrintStringS(1,0,"  Please hit 0.  ");
                    break;
                case VN:
                    LcdPrintStringS(0,0,"  DA XAY RA LOI  ");
                    LcdPrintStringS(1,0," Hay nhan nut 0 ");
                    break;
                case FR:
                    LcdPrintStringS(0,0,"     ERREUR     ");
                    LcdPrintStringS(1,0," Appuyez sur 0 ");
                    break;
            }
            if (isButton0())
            {
                //setState(CLOCK);
                alarm = WAIT;
            }
            break;
            
    }
}
