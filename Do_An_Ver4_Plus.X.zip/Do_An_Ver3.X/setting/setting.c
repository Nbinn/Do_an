
#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"


#define SETSECOND   1
#define SETMINUTE   2
#define SETHOUR     3
#define SETDAY      4  
#define SETDATE     5
#define SETMONTH    6
#define SETYEAR     7
#define WAIT        30
#define ERROR       31

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6

#define     ENG            0
#define     FR             1
#define     VN             7

unsigned char secondSet = 0;
unsigned char minuteSet = 0;
unsigned char hourSet = 0;
unsigned char daySet = 0;
unsigned char dateSet = 0;
unsigned char monthSet = 0;
unsigned char yearSet = 0;
unsigned char modeSet = 0;
unsigned char tmp;
unsigned char blinkSet = 0;
unsigned char first = 0, secon = 0;
unsigned char setting = WAIT;


void DisplayTimeSettings();

/*unsigned char monthArray[12] = {1,2,3,4,5,6,7,8,9,10,11,12};

unsigned char dayOfWeek(unsigned char date, unsigned char month, unsigned char year)
{
    unsigned long theYear = year + 2000;
    unsigned char day = (date += month < 3 ? theYear-- : theYear - 2, 23*month/9 + date + 4 + theYear/4 - theYear/100 + theYear/400)%7;
    return day+1;
}*/

static int monthArray[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
unsigned char dayOfWeek(unsigned char date, int month, int year){
    year += 2000;
        year -= month < 3;
    return ( year + year/4 - year/100 + year/400 + monthArray[month - 1] + date) % 7 + 1;
}

unsigned int errorCheck(unsigned char second,unsigned char minute,unsigned char hour,unsigned char date,unsigned char month, unsigned char year)
{
    if(second > 59){
        return 1;
    }
    if(minute > 59){
        return 1;
    }
    if(hour > 23){
        return 1;
    }
    if (date <= 0)
        return 1;
    if(month==1 || month==3 || month==5 || month==7 || month== 8|| month==10||month==12){
        if(date > 31){
            return 1;
        }
    }
    if(month==4 || month==6 || month==9 || month==11){
        if(date > 30){
            return 1;
        }

    }
    if(month == 2 && year%4 == 0 && year != 0){
        if(date > 29){
            return 1;
        }
  
    }
    else if (month == 2){
        if(date > 28){
            return 1;
        }
 
    }
    if(month > 12){
        return 1;
    }
    if(year > 99){
        return 1;
    }
    return 0;
}

void validateSetting(unsigned char second,unsigned char minute,unsigned char hour,unsigned char date,unsigned char month, unsigned char year){
    if(second > 59){
        second %= 60;
        minute += 1;
    }
    if(minute > 59){
        minute %=60;
        hour += 1;
    }
    if(hour > 23){
        tmp = hour/24;
        hour %= 24;
        date += tmp;
    }
    if(month==1 || month==3 || month==5 || month==7 || month== 8|| month==10||month==12){
        if(date > 31){
            date %= 31;
            month+=1;
        }
    }
    if(month==4 || month==6 || month==9 || month==11){
        if(date > 30){
            date %= 31;
             month += 1;
        }

    }
    if(month == 2 && (year%4 == 0)){
        if(date > 29){
            date %= 30;
            month += 1;
        }
  
    }
    else{
        if(date > 28){
            date %= 29;
                   month += 1;
        }
 
    }
    if(month > 12){
        month = 1;
        year++;
    }
    if(year > 99){
        year = 99;
    }
    
    //day = dayOfWeek(date, month, year);
    
    Write_DS1307(ADDRESS_SECOND, second);
    Write_DS1307(ADDRESS_MINUTE, minute);
    Write_DS1307(ADDRESS_HOUR, hour);
    //Write_DS1307(ADDRESS_DAY, day);
    Write_DS1307(ADDRESS_DATE, date);
    Write_DS1307(ADDRESS_MONTH, month);
    Write_DS1307(ADDRESS_YEAR, year);
    setZone(7);
}
void validate(char hour,unsigned char day,unsigned char date,unsigned char month, unsigned char year){
    if(hour > 23){
        hour %= 24;
        day += 1;
        date += 1;
        if(day > 7){
            day = 1;
        }
        if(month==1 || month==3 || month==5 || month==7 || month== 8|| month==10||month==12){
            if(date > 31){
                date = 1;
                month+=1;
            }
        }
        else if(month==4 || month==6 || month==9 || month==11){
            if(date > 30){
                date = 1;
                month += 1;
            }
        }
        else if(month == 2 && (year%4 == 0)){
            if(date > 29){
                date = 1;
                month += 1;
            }

        }
        else{
            if(date > 28){
                date = 1;
                month += 1;
            }
        }
        if(month > 12){
            month = 1;
            year++;
        }
        if(year > 99){
            year = 0;
        }
    }
    else if(hour < 0){
        hour += 24;
        day -= 1;
        date -= 1;
        if(day < 1){
            day = 7;
        }
        if(month==1 || month==2 || month==4 || month==6 || month== 8|| month==9||month==11){
            if(date < 1){
                date = 31;
                month-=1;
            }
        }
        else if(month==5 || month==7 || month==10 || month==12){
            if(date < 1){
                date = 30;
                month -= 1;
            }
        }
        else if(month == 3 && (year%4 == 0) && year != 0){
            if(date < 1){
                date = 29;
                month -= 1;
            }
        }
        else{
            if(date < 1){
                date = 28;
                month -= 1;
            }
        }
        if(month < 1){
            month = 12;
            year--;
        }
        if(year < 0){
            year = 99;
        }
    }
    Write_DS1307(ADDRESS_HOUR, hour);
    Write_DS1307(ADDRESS_DAY, day);
    Write_DS1307(ADDRESS_DATE, date);
    Write_DS1307(ADDRESS_MONTH, month);
    Write_DS1307(ADDRESS_YEAR, year);
}

void settingTime(){
    switch(setting){
        case WAIT:
            daySet = Read_DS1307(ADDRESS_DAY);
            hourSet = Read_DS1307(ADDRESS_HOUR);
            minuteSet = Read_DS1307(ADDRESS_MINUTE);
            secondSet = Read_DS1307(ADDRESS_SECOND);
            dateSet = Read_DS1307(ADDRESS_DATE);
            monthSet = Read_DS1307(ADDRESS_MONTH);
            yearSet = Read_DS1307(ADDRESS_YEAR);
            DisplayTimeSettings();
            setting = SETHOUR;
            //LcdClearS();

                break;
        case SETSECOND:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,10,"_");
                }
                buttonSetting(&first);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(0,10,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,11,"_");
                }
                buttonSetting(&secon);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    secondSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(0,11,secondSet%10);
                    setting = SETDATE;
                }
            }
            break;
        case SETMINUTE:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,7,"_");
                }
                buttonSetting(&first);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(0,7,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,8,"_");
                }
                buttonSetting(&secon);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    minuteSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(0,8,minuteSet%10);
                    setting = SETSECOND;
                }
            }
            break;
        case SETHOUR:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,4,"_");
                }
                buttonSetting(&first);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(0,4,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(0,5,"_");
                }
                buttonSetting(&secon);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    hourSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(0,5,hourSet%10);
                    setting = SETMINUTE;
                }
            }
            break;
        case SETDATE:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,6,"_");
                }
                buttonSetting(&first);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,6,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,7,"_");
                }
                buttonSetting(&secon);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    dateSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(1,7,dateSet%10);
                    setting = SETMONTH;
                }
            }
            break;
        case SETMONTH:
           if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(isButton0())
            {
                monthSet += 1;
            if(monthSet > 12)
                monthSet = 1;
            }
            blinkSet = (blinkSet+1)%20;
            if(blinkSet > 15){
                LcdPrintStringS(1,2,"___");
            }
            switch (getLang())
            {
                case FR:
                    switch(monthSet)
                    {
                        case 1:
                            LcdPrintStringS(1,2,"JAN");
                            break;
                        case 2:
                            LcdPrintStringS(1,2,"FEV");
                            break;
                        case 3:
                            LcdPrintStringS(1,2,"MAR");
                            break;
                        case 4:
                            LcdPrintStringS(1,2,"AVR");
                            break;
                        case 5:
                            LcdPrintStringS(1,2,"MAI");
                            break;
                        case 6:
                            LcdPrintStringS(1,2,"JUI");
                            break;
                        case 7:
                            LcdPrintStringS(1,2,"JUL");
                            break;
                        case 8:
                            LcdPrintStringS(1,2,"AOU");
                            break;
                        case 9:
                            LcdPrintStringS(1,2,"SEP");
                            break;
                        case 10:
                            LcdPrintStringS(1,2,"OCT");
                            break;
                        case 11:
                            LcdPrintStringS(1,2,"NOV");
                            break;
                        case 12:
                            LcdPrintStringS(1,2,"DEC");
                            break;
                    }
                    break;
                case VN:
                    switch(monthSet)
                        {
                            case 1:
                                LcdPrintStringS(1,2,"T01");
                                break;
                            case 2:
                                LcdPrintStringS(1,2,"T02");
                                break;
                            case 3:
                                LcdPrintStringS(1,2,"T03");
                                break;
                            case 4:
                                LcdPrintStringS(1,2,"T04");
                                break;
                            case 5:
                                LcdPrintStringS(1,2,"T05");
                                break;
                            case 6:
                                LcdPrintStringS(1,2,"T06");
                                break;
                            case 7:
                                LcdPrintStringS(1,2,"T07");
                                break;
                            case 8:
                                LcdPrintStringS(1,2,"T08");
                                break;
                            case 9:
                                LcdPrintStringS(1,2,"T09");
                                break;
                            case 10:
                                LcdPrintStringS(1,2,"T10");
                                break;
                            case 11:
                                LcdPrintStringS(1,2,"T11");
                                break;
                            case 12:
                                LcdPrintStringS(1,2,"T12");
                                break;
                        }
                    break;
                default:
                    switch(monthSet){
                        case 1:
                            LcdPrintStringS(1,2,"JAN");
                            break;
                        case 2:
                            LcdPrintStringS(1,2,"FEB");
                            break;
                        case 3:
                            LcdPrintStringS(1,2,"MAR");
                            break;
                        case 4:
                            LcdPrintStringS(1,2,"APR");
                            break;
                        case 5:
                            LcdPrintStringS(1,2,"MAY");
                            break;
                        case 6:
                            LcdPrintStringS(1,2,"JUN");
                            break;
                        case 7:
                            LcdPrintStringS(1,2,"JUL");
                            break;
                        case 8:
                            LcdPrintStringS(1,2,"AUG");
                            break;
                        case 9:
                            LcdPrintStringS(1,2,"SEP");
                            break;
                        case 10:
                            LcdPrintStringS(1,2,"OCT");
                            break;
                        case 11:
                            LcdPrintStringS(1,2,"NOV");
                            break;
                        case 12:
                            LcdPrintStringS(1,2,"DEC");
                            break;
                    }
                    break;
            }
            
            if(isButtonAsterisk()){
                setting = SETYEAR;
            }
            break;
        case SETYEAR:
            if (isButtonHash())
            {
                setState(SELECT);
                setting = WAIT;
            }
            if(modeSet == 0){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,11,"_");
                }
                buttonSetting(&first);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,11,first);
                }
            }
            else if (modeSet == 1){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,12,"_");
                }
                buttonSetting(&secon);
                if(getDone()){
                    modeSet = 2;
                    setDone(0);
                    yearSet = first*10+secon;
                    first = 0;
                    secon = 0;
                    LcdPrintNumS(1,12,yearSet%10);
                }
                
            }
            else if(modeSet == 2){
                if(isButtonAsterisk()){
                    modeSet = 0;
                    
                    //LcdPrintNumS(1,1,monthSet);
                    if (!errorCheck(secondSet,minuteSet,hourSet,dateSet,monthSet,yearSet))
                    {
                        //validateSetting(secondSet,minuteSet,hourSet,dateSet,monthSet,yearSet);
                            Write_DS1307(ADDRESS_HOUR, hourSet);
                            Write_DS1307(ADDRESS_MINUTE, minuteSet);
                            Write_DS1307(ADDRESS_SECOND, secondSet);
                            Write_DS1307(ADDRESS_DATE, dateSet);
                            Write_DS1307(ADDRESS_MONTH, monthSet);
                            Write_DS1307(ADDRESS_YEAR, yearSet);
                        daySet = dayOfWeek(dateSet, monthSet, yearSet);
                        Write_DS1307(ADDRESS_DAY, daySet);
                        setting = WAIT;
                        setZone(7);
                        setState(CLOCK);
                    }
                    else
                    {
                        setting = ERROR;
                    }
                }
            }
            /*if(!modeSet){
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,11," ");
                }
                buttonSetting(&first);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,12,first);
                }
            }
            else{
                blinkSet = (blinkSet+1)%20;
                if(blinkSet > 15){
                    LcdPrintStringS(1,9,"    ");
                }
                buttonSetting(&secon);
                if(getDone()){
                    modeSet ^= 0x01;
                    setDone(0);
                    yearSet = first*10+secon;
                    first = 0;
                    secon = 0;
                }
                                    LcdPrintNumS(1,9,20);
                    LcdPrintNumS(1,11,yearSet);
                if(isButtonAsterisk()){
                    validateSetting(secondSet,minuteSet,hourSet,dateSet,monthSet,yearSet);
                    setting = WAIT;
                    setState(CLOCK);
                }
            }*/
            break;
        case ERROR:
            LcdClearS();
            switch (getLang())
            {
                default:
                    LcdPrintStringS(0,4,"ERROR(S)");
                    LcdPrintStringS(1,0,"  Please hit 0.  ");
                    break;
                case VN:
                    LcdPrintStringS(0,0,"  DA XAY RA LOI  ");
                    LcdPrintStringS(1,0," Hay nhan nut 0 ");
                    break;
                case FR:
                    LcdPrintStringS(0,0,"     ERREUR     ");
                    LcdPrintStringS(1,0," Appuyez sur 0 ");
                    break;
            }
            if (isButton0())
            {
                //setState(CLOCK);
                setting = WAIT;
            }
            break;
    }
}

void DisplayTimeSettings()
{
    //////day
    LcdClearS();
    switch (getLang())
    {
        case FR:
            switch(daySet)
            {
                case 1:
                    LcdPrintStringS(1,2,"JAN");
                    break;
                case 2:
                    LcdPrintStringS(1,2,"FEV");
                    break;
                case 3:
                    LcdPrintStringS(1,2,"MAR");
                    break;
                case 4:
                    LcdPrintStringS(1,2,"AVR");
                    break;
                case 5:
                    LcdPrintStringS(1,2,"MAI");
                    break;
                case 6:
                    LcdPrintStringS(1,2,"JUI");
                    break;
                case 7:
                    LcdPrintStringS(1,2,"JUL");
                    break;
                case 8:
                    LcdPrintStringS(1,2,"AOU");
                    break;
                case 9:
                    LcdPrintStringS(1,2,"SEP");
                    break;
                case 10:
                    LcdPrintStringS(1,2,"OCT");
                    break;
                case 11:
                    LcdPrintStringS(1,2,"NOV");
                    break;
                case 12:
                    LcdPrintStringS(1,2,"DEC");
                    break;
            }
            break;
        case VN:
            switch(daySet)
            {
                case 1:
                    LcdPrintStringS(0,0," CN");
                    break;
                case 2:
                    LcdPrintStringS(0,0," T2");
                    break;
                case 3:
                    LcdPrintStringS(0,0," T3");
                    break;
                case 4:
                    LcdPrintStringS(0,0," T4");
                    break;
                case 5:
                    LcdPrintStringS(0,0," T5");
                    break;
                case 6:
                    LcdPrintStringS(0,0," T6");
                    break;
                case 7:
                    LcdPrintStringS(0,0," T7");
                    break;
            }
            break;
        default:
            switch(daySet)
            {
                case 1:
                    LcdPrintStringS(0,0,"SUN");
                    break;
                case 2:
                    LcdPrintStringS(0,0,"MON");
                    break;
                case 3:
                    LcdPrintStringS(0,0,"TUE");
                    break;
                case 4:
                    LcdPrintStringS(0,0,"WED");
                    break;
                case 5:
                    LcdPrintStringS(0,0,"THU");
                    break;
                case 6:
                    LcdPrintStringS(0,0,"FRI");
                    break;
                case 7:
                    LcdPrintStringS(0,0,"SAT");
                    break;
            }
            break;
    } 
    if(hourSet < 10)
    {
        LcdPrintStringS(0,4,"0");
        LcdPrintNumS(0,5,hourSet);
    }
    else
        LcdPrintNumS(0,4,hourSet);
    
    LcdPrintStringS(0,6,":");
    if(minuteSet < 10)
    {
        LcdPrintStringS(0,7,"0");
        LcdPrintNumS(0,8,minuteSet);
    }
    else
        LcdPrintNumS(0,7,minuteSet);

    LcdPrintStringS(0,9,":");
    if(secondSet < 10)
    {
        LcdPrintStringS(0,10,"0");
        LcdPrintNumS(0,11,secondSet);
    }
    else
        LcdPrintNumS(0,10,secondSet);
    
    switch (getLang())
    {
        default:
            switch(monthSet)
            {
                case 1:
                    LcdPrintStringS(1,2,"JAN");
                    break;
                case 2:
                    LcdPrintStringS(1,2,"FEB");
                    break;
                case 3:
                    LcdPrintStringS(1,2,"MAR");
                    break;
                case 4:
                    LcdPrintStringS(1,2,"APR");
                    break;
                case 5:
                    LcdPrintStringS(1,2,"MAY");
                    break;
                case 6:
                    LcdPrintStringS(1,2,"JUN");
                    break;
                case 7:
                    LcdPrintStringS(1,2,"JUL");
                    break;
                case 8:
                    LcdPrintStringS(1,2,"AUG");
                    break;
                case 9:
                    LcdPrintStringS(1,2,"SEP");
                    break;
                case 10:
                    LcdPrintStringS(1,2,"OCT");
                    break;
                case 11:
                    LcdPrintStringS(1,2,"NOV");
                    break;
                case 12:
                    LcdPrintStringS(1,2,"DEC");
                    break;
            }
            break;
        case VN:
            switch(monthSet)
            {
                case 1:
                    LcdPrintStringS(1,2,"T01");
                    break;
                case 2:
                    LcdPrintStringS(1,2,"T02");
                    break;
                case 3:
                    LcdPrintStringS(1,2,"T03");
                    break;
                case 4:
                    LcdPrintStringS(1,2,"T04");
                    break;
                case 5:
                    LcdPrintStringS(1,2,"T05");
                    break;
                case 6:
                    LcdPrintStringS(1,2,"T06");
                    break;
                case 7:
                    LcdPrintStringS(1,2,"T07");
                    break;
                case 8:
                    LcdPrintStringS(1,2,"T08");
                    break;
                case 9:
                    LcdPrintStringS(1,2,"T09");
                    break;
                case 10:
                    LcdPrintStringS(1,2,"T10");
                    break;
                case 11:
                    LcdPrintStringS(1,2,"T11");
                    break;
                case 12:
                    LcdPrintStringS(1,2,"T12");
                    break;
            }
            break;
            
    }

    LcdPrintStringS(1,5," ");
    if(dateSet < 10)
    {
        LcdPrintStringS(1,6,"0");
        LcdPrintNumS(1,7,dateSet);
    }
    else
        LcdPrintNumS(1,6,dateSet);
    LcdPrintStringS(1,8," ");
    LcdPrintNumS(1,9,20);
    if (yearSet >= 10)
        LcdPrintNumS(1,11,yearSet);
    else
    {
        LcdPrintNumS(1,11,0);
        LcdPrintNumS(1,12,yearSet);
    }
}

