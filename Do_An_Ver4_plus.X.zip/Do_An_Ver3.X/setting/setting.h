/* 
 * File:   setting.h
 * Author: Tho Nhan
 *
 * Created on December 14, 2021, 2:52 PM
 */

#ifndef SETTING_H
#define	SETTING_H

void validate(char hour,unsigned char day,unsigned char date,unsigned char month, unsigned char year);
void validateSetting(unsigned char second,unsigned char minute,unsigned char hour,unsigned char day,unsigned char date,unsigned char month, unsigned char year);
void settingTime(void);

#endif	/* SETTING_H */

