/* 
 * File:   countdown.h
 * Author: Tho Nhan
 *
 * Created on December 18, 2021, 3:47 PM
 */

#ifndef COUNTDOWN_H
#define	COUNTDOWN_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* COUNTDOWN_H */

