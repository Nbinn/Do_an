#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"
#include "../timer/timer.h"

#define START   1
#define STOP    2
#define WAIT    30

unsigned char stopWatch = WAIT;
unsigned char minuteStopWatch = 0, secondStopWatch = 0, centisecondStopWatch = 0;
void runStopWatch(){
    if(flag_timer0){
        SetTimer0_ms(0);
        centisecondStopWatch++;
        flag_timer0 = 0;
    }
    if(centisecondStopWatch > 99){
        centisecondStopWatch = 0;
        secondStopWatch++;
    }
    if(secondStopWatch>59){
        secondStopWatch = 0;
        minuteStopWatch++;
    }
    LcdPrintStringS(0,0,"   STOPWATCH    ");
    LcdPrintStringS(1,0,"  ");
    if(minuteStopWatch < 10)
    {
        LcdPrintStringS(1,2,"0");
        LcdPrintNumS(1,3,minuteStopWatch);
    }
    else
        LcdPrintNumS(1,2,minuteStopWatch);
    LcdPrintStringS(1,4,":");
    if(secondStopWatch < 10)
    {
        LcdPrintStringS(1,5,"0");
        LcdPrintNumS(1,6,secondStopWatch);
    }
    else
        LcdPrintNumS(1,5,secondStopWatch);
    LcdPrintStringS(1,7,":");
    if(centisecondStopWatch < 10)
    {
        LcdPrintStringS(1,8,"0");
        LcdPrintNumS(1,9,centisecondStopWatch);
    }
    else
        LcdPrintNumS(1,8,centisecondStopWatch);
    LcdPrintStringS(1,10,"        ");
}
void displayStopWatch(){
    LcdPrintStringS(0,0,"   STOPWATCH    ");
    LcdPrintStringS(1,0,"  ");
    if(minuteStopWatch < 10)
    {
        LcdPrintStringS(1,2,"0");
        LcdPrintNumS(1,3,minuteStopWatch);
    }
    else
        LcdPrintNumS(1,2,minuteStopWatch);
    LcdPrintStringS(1,4,":");
    if(secondStopWatch < 10)
    {
        LcdPrintStringS(1,5,"0");
        LcdPrintNumS(1,6,secondStopWatch);
    }
    else
        LcdPrintNumS(1,5,secondStopWatch);
    LcdPrintStringS(1,7,":");
    if(centisecondStopWatch < 10)
    {
        LcdPrintStringS(1,8,"0");
        LcdPrintNumS(1,9,centisecondStopWatch);
    }
    else
        LcdPrintNumS(1,8,centisecondStopWatch);
    LcdPrintStringS(1,10,"        ");

    
}
void stopwatch(){
    switch(stopWatch){
        case WAIT:
            minuteStopWatch = 0; 
            secondStopWatch = 0; 
            centisecondStopWatch = 0;
            displayStopWatch();
            if(isButtonAsterisk()){
                stopWatch = START;
                SetTimer0_ms(10);
            }
            break;
        case START:
            if(isButton0()){
                stopWatch = STOP;
            }
            runStopWatch();
            break;
        case STOP:
            if(isButton0()){
                stopWatch = START;
            }
            if(isButtonAsterisk()){
                stopWatch = WAIT;
            }
            break;
    }
}