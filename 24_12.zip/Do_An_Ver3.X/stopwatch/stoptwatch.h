/* 
 * File:   stoptwatch.h
 * Author: Tho Nhan
 *
 * Created on December 19, 2021, 12:53 PM
 */

#ifndef STOPTWATCH_H
#define	STOPTWATCH_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* STOPTWATCH_H */

