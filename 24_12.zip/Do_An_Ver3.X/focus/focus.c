#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"
#include "../timer/timer.h"
#define     ADDRESS_YEAR_FOCUS      0x2A
#define     ADDRESS_MONTH_FOCUS     0x2B
#define     ADDRESS_DATE_FOCUS      0x2C
#define     ADDRESS_HOUR_FOCUS      0x2D
#define     ADDRESS_MINUTE_FOCUS    0x2E
#define     ADDRESS_SECOND_FOCUS    0x2F

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6
#define     SETTINGS       7

#define     HOURFOCUS      1
#define     MINUTEFOCUS    2
#define     SECONDFOCUS    3
#define     FOCUSS         4
#define     TIMEEEEE       5
#define     WAIT           30
#define     ERROR          31

#define     ENG            0
#define     FR             1
#define     VN             7

// Actual variables used for counting down.
unsigned char hourFocus = 0, minuteFocus = 0, secFocus = 0;
unsigned char hourStartFocus = 0, minuteStartFocus = 0, secondStartFocus = 0;
unsigned char yearStartFocus = 0, monthStartFocus = 0, dateStartFocus = 0;
unsigned char hourEndFocus = 0,minuteEndFocus = 0,secondEndFocus = 0;
unsigned char yearEndFocus = 0, monthEndFocus = 0, dateEndFocus = 0;
unsigned char focus = WAIT;
unsigned char modeFocus = 0;
unsigned char firstFocus = 0, secondFocus = 0,blinkFocus = 0;
unsigned char tempFocus = 0;
unsigned char hourShowFocus = 0, minuteShowFocus = 0, secondShowFocus = 0;
unsigned int errorCheckFocus(void)
{
    if (minuteFocus > 59)
        return 1;
    if (secFocus > 59)
        return 1;
    return 0;
}
void calculateFoCus(){
    secondEndFocus = secFocus + secondStartFocus;
    minuteEndFocus = minuteFocus + minuteStartFocus;
    hourEndFocus = hourFocus + hourStartFocus;
    if(secondEndFocus > 59){
        secondEndFocus -= 60;
        minuteEndFocus += 1;
    }
    if(minuteEndFocus > 59){
        minuteEndFocus -= 60;
        hourEndFocus += 1;
    }
   if(hourEndFocus > 23){
        tempFocus = hourEndFocus/24;
        hourEndFocus %= 24;
        dateEndFocus = dateStartFocus + tempFocus;
    }
    
        if(monthStartFocus==1 || monthStartFocus==3 || monthStartFocus==5 || monthStartFocus==7 || monthStartFocus== 8|| monthStartFocus==10 || monthStartFocus==12){
            if(dateEndFocus > 31){
                dateEndFocus -= 31;
                monthEndFocus = monthStartFocus+1;
            }
        }
        if(monthStartFocus==4 || monthStartFocus==6 || monthStartFocus==9 || monthStartFocus==11){
            if(dateEndFocus > 30){
                dateEndFocus -= 30;
                 monthEndFocus = monthStartFocus+1;
            }
        }
        if(monthStartFocus == 2 && (yearStartFocus%4 == 0)){
            if(dateEndFocus > 29){
                dateEndFocus -= 29;
                monthEndFocus = monthStartFocus+1;
            }
        }
        else{
            if(dateEndFocus > 28){
                dateEndFocus -= 28;
                monthEndFocus = monthStartFocus+1;
            }
        }
    if(monthEndFocus > 12){
        monthEndFocus = 1;
        yearEndFocus = yearStartFocus + 1;
    }

    Write_DS1307(ADDRESS_YEAR_FOCUS,yearEndFocus);
    Write_DS1307(ADDRESS_MONTH_FOCUS,monthEndFocus);
    Write_DS1307(ADDRESS_DATE_FOCUS,dateEndFocus);
    Write_DS1307(ADDRESS_HOUR_FOCUS,hourEndFocus);
    Write_DS1307(ADDRESS_MINUTE_FOCUS,minuteEndFocus);
    Write_DS1307(ADDRESS_SECOND_FOCUS,secondEndFocus);
}
void showFocus(){
    unsigned char secondNow = Read_DS1307(ADDRESS_SECOND);
    unsigned char minuteNow = Read_DS1307(ADDRESS_MINUTE);
    unsigned char hourNow = Read_DS1307(ADDRESS_HOUR);
    unsigned char dateNow = Read_DS1307(ADDRESS_DATE);
    unsigned char monthNow = Read_DS1307(ADDRESS_MONTH);
    unsigned char yearNow = Read_DS1307(ADDRESS_YEAR);
    
    
    unsigned char second = Read_DS1307(ADDRESS_SECOND_FOCUS);
    unsigned char minute = Read_DS1307(ADDRESS_MINUTE_FOCUS);
    unsigned char hour = Read_DS1307(ADDRESS_HOUR_FOCUS);
    unsigned char date = Read_DS1307(ADDRESS_DATE_FOCUS);
    unsigned char month = Read_DS1307(ADDRESS_MONTH_FOCUS);
    unsigned char year = Read_DS1307(ADDRESS_YEAR_FOCUS);
    if(year > yearNow){
       month = 13;
    } 
    if(month > monthNow){
        if(monthNow == 1 || monthNow == 2 || monthNow == 4 || monthNow == 6 || monthNow == 8 || monthNow == 9 || monthNow == 11){
            date += 31;
        }
        else if(monthNow == 5 || monthNow == 7 || monthNow == 10 || monthNow == 12){
            date +=30;
        }
        else if(monthNow == 3 || (year%4 == 0)){
            date +=29;
        }
        else date += 28;
    }
    if(date > dateNow){
        hour += (date-dateNow)*24;
    }
    if(hour > hourNow){
        hourShowFocus = hour - hourNow;
    }
    else{
        hourShowFocus = 0;
    }
    if(second < secondNow){
        second += 60;
        minute -= 1;
    }
    if(minute < minuteNow){
        hourShowFocus -= 1;
        minute += 60;
    }
    secondShowFocus = second - secondNow;
    minuteShowFocus = minute - minuteNow;
   
    LcdPrintStringS(0,0,"   FOCUS    ");
            LcdPrintStringS(1,0,"  ");
            if(hourShowFocus < 10)
            {
                LcdPrintStringS(1,4,"0");
                LcdPrintNumS(1,5,hourShowFocus);
            }
            else
                LcdPrintNumS(1,4,hourShowFocus);
            LcdPrintStringS(1,6,":");
            if(minuteShowFocus < 10)
            {
                LcdPrintStringS(1,7,"0");
                LcdPrintNumS(1,8,minuteShowFocus);
            }
            else
                LcdPrintNumS(1,7,minuteShowFocus);
            LcdPrintStringS(1,9,":");
            if(secondShowFocus < 10)
            {
                LcdPrintStringS(1,10,"0");
                LcdPrintNumS(1,11,secondShowFocus);
            }
            else
                LcdPrintNumS(1,10,secondShowFocus);
            LcdPrintStringS(1,12,"     ");

}

unsigned char checkFocus(){
    if(hourShowFocus > 0 || minuteShowFocus > 0 || secondShowFocus > 0){
        if(isButton0())
            return 1;
        else if(isButton1())
            return 1;
        else if(isButton2())
            return 1;
        else if(isButton3())
            return 1;
        else if(isButton4())
            return 1;
        else if(isButton5())
            return 1;
        else if(isButton6())
            return 1;
        else if(isButton7())
            return 1;
        else if(isButton8())
            return 1;
        else if(isButton9())
            return 1;
        else if(isButtonAsterisk())
            return 1;
        else if(isButtonHash())
            return 1;
        else if(isButtonA())
            return 1;
        else if(isButtonB())
            return 1;
        else if(isButtonC())
            return 1;
        else if(isButtonD())
            return 1;
    }
}

void setFocus(void){
    switch (focus){
        case WAIT:   
            LcdClearS();
            LcdPrintStringS(0,0,"   FOCUS    ");
            LcdPrintStringS(1,0,"  ");
            if(hourFocus < 10)
            {
                LcdPrintStringS(1,4,"0");
                LcdPrintNumS(1,5,hourFocus);
            }
            else
                LcdPrintNumS(1,4,hourFocus);
            LcdPrintStringS(1,6,":");
            if(minuteFocus < 10)
            {
                LcdPrintStringS(1,7,"0");
                LcdPrintNumS(1,8,minuteFocus);
            }
            else
                LcdPrintNumS(1,7,minuteFocus);
            LcdPrintStringS(1,9,":");
            if(secFocus < 10)
            {
                LcdPrintStringS(1,10,"0");
                LcdPrintNumS(1,11,secFocus);
            }
            else
                LcdPrintNumS(1,10,secFocus);
            LcdPrintStringS(1,12,"     ");
            focus = HOURFOCUS;
            break;
        case SECONDFOCUS:
            if (isButtonHash())
            {
                setState(SELECT);
                focus = WAIT;
            }
            if(modeFocus == 0){
                blinkFocus = (blinkFocus+1)%20;
                if(blinkFocus > 15){
                    LcdPrintStringS(1,10,"_");
                }
                buttonSetting(&firstFocus);
                if(getDone()){
                    modeFocus = 1;
                    setDone(0);
                    LcdPrintNumS(1,10,firstFocus);
                }
            }
            else if(modeFocus == 1){
                blinkFocus = (blinkFocus+1)%20;
                if(blinkFocus > 15){
                    LcdPrintStringS(1,11,"_");
                }
                buttonSetting(&secondFocus);
                if(getDone()){
                    modeFocus = 2;
                    setDone(0);
                    secFocus = firstFocus*10+secondFocus;
                    firstFocus = 0;
                    secondFocus = 0;
                    LcdPrintNumS(1,11,secFocus%10);
                    
                }
            }
            else if(modeFocus == 2){
                if(isButtonAsterisk()){   
                    if(!errorCheckFocus()){
                        secondStartFocus = Read_DS1307(ADDRESS_SECOND);
                        minuteStartFocus = Read_DS1307(ADDRESS_MINUTE);
                        hourStartFocus = Read_DS1307(ADDRESS_HOUR);
                        dateStartFocus = Read_DS1307(ADDRESS_DATE);
                        monthStartFocus = Read_DS1307(ADDRESS_MONTH);
                        yearStartFocus = Read_DS1307(ADDRESS_YEAR);
                        calculateFoCus();
                        modeFocus = 0;
                        focus = FOCUSS;
                    }
                    else
                    {
                        focus = ERROR;
                        modeFocus = 0;
                    }
                }
            }
            break;
        case MINUTEFOCUS:
            if (isButtonHash())
            {
                setState(SELECT);
                focus = WAIT;
            }
            if(!modeFocus){
                blinkFocus = (blinkFocus+1)%20;
                if(blinkFocus > 15){
                    LcdPrintStringS(1,7,"_");
                }
                buttonSetting(&firstFocus);
                if(getDone()){
                    modeFocus ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,7,firstFocus);
                }
            }
            else{
                blinkFocus = (blinkFocus+1)%20;
                if(blinkFocus > 15){
                    LcdPrintStringS(1,8,"_");
                }
                buttonSetting(&secondFocus);
                if(getDone()){
                    modeFocus ^= 0x01;
                    setDone(0);
                    minuteFocus = firstFocus*10+secondFocus;
                    firstFocus = 0;
                    secondFocus = 0;
                    LcdPrintNumS(1,8,minuteFocus%10);
                    focus = SECONDFOCUS;
                }
            }
            break;
        case HOURFOCUS:
            if (isButtonHash())
            {
                setState(SELECT);
                focus = WAIT;
            }
            if(!modeFocus){
                blinkFocus = (blinkFocus+1)%20;
                if(blinkFocus > 15){
                    LcdPrintStringS(1,4,"_");
                }
                buttonSetting(&firstFocus);
                if(getDone()){
                    modeFocus ^= 0x01;
                    setDone(0);
                    LcdPrintNumS(1,4,firstFocus);
                }
            }
            else{
                blinkFocus = (blinkFocus+1)%20;
                if(blinkFocus > 15){
                    LcdPrintStringS(1,5,"_");
                }
                buttonSetting(&secondFocus);
                if(getDone()){
                    modeFocus ^= 0x01;
                    setDone(0);
                    hourFocus = firstFocus*10+secondFocus;
                    firstFocus = 0;
                    secondFocus = 0;
                    LcdPrintNumS(1,5,hourFocus%10);
                    focus = MINUTEFOCUS;
                }
            }
            break;
        case ERROR:
            LcdClearS();
            switch (getLang())
            {
                default:
                    LcdPrintStringS(0,4,"ERROR(S)");
                    LcdPrintStringS(1,0,"  Please hit 0.  ");
                    break;
                case VN:
                    LcdPrintStringS(0,0,"  DA XAY RA LOI  ");
                    LcdPrintStringS(1,0," Hay nhan nut 0 ");
                    break;
                case FR:
                    LcdPrintStringS(0,0,"     ERREUR     ");
                    LcdPrintStringS(1,0," Appuyez sur 0 ");
                    break;
            }
            if (isButton0())
            {
                //setState(CLOCK);
                focus = WAIT;
            }
            break;
        case FOCUSS:
            showFocus();
            break;
        case TIMEEEEE:
            LcdClearS();
            LcdPrintStringS(0,0,"TIMEEEEEEEEEEEE!");
            LcdPrintStringS(1,0,"  Please hit 0  ");
            modeFocus = 0;
            //secondFocus = 0;
            //minuteFocus = 0;
            hourFocus = 0;
            secondEndFocus = 0;
            minuteEndFocus = 0;
            hourEndFocus = 0;
            if (isButton0())
                focus = WAIT;
            break;
    }
}
