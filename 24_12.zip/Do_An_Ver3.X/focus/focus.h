/* 
 * File:   focus.h
 * Author: Tho Nhan
 *
 * Created on December 23, 2021, 10:43 PM
 */

#ifndef FOCUS_H
#define	FOCUS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FOCUS_H */

