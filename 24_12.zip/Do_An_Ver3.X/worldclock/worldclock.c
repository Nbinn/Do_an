
#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"

#define     ENG         0
#define     FR          1 // France
#define     EG          2 // Egypt
#define     RU          3 // Moscow, Russia
#define     OM          4 // Oman
#define     MV          5 // Maldives
#define     BT          6 // Bhutan
#define     VN          7 // Viet Nam
#define     CN          8 // China
#define     JP          9 // Japan
#define     WAIT        30

#define     SELECT         0 
#define     CLOCK          1 
#define     ALARMTIME      2
#define     FOCUS          3 
#define     ZONE           4
#define     STOPWATCH      5 
#define     COUNTDOWN      6

#define     ADDRESS_ZONE            0x13

unsigned char timeZone = WAIT;
unsigned char secondZone = 0,minuteZone = 0;
char hourZone = 0;
unsigned char dayZone = 0;
signed char dateZone = 0,monthZone = 0,yearZone = 0;
unsigned char temp;
unsigned char modeZone = 1;
void readTime(void){
    secondZone = Read_DS1307(ADDRESS_SECOND);
    minuteZone = Read_DS1307(ADDRESS_MINUTE);
    hourZone = Read_DS1307(ADDRESS_HOUR);
    dayZone = Read_DS1307(ADDRESS_DAY);
    dateZone = Read_DS1307(ADDRESS_DATE);
    monthZone = Read_DS1307(ADDRESS_MONTH);
    yearZone = Read_DS1307(ADDRESS_YEAR);
}
void writeTime(void){
    Write_DS1307(ADDRESS_SECOND, secondZone);
    Write_DS1307(ADDRESS_MINUTE, minuteZone);
    Write_DS1307(ADDRESS_HOUR, hourZone);
    Write_DS1307(ADDRESS_DAY, dayZone);
    Write_DS1307(ADDRESS_DATE, dateZone);
    Write_DS1307(ADDRESS_MONTH, monthZone);
    Write_DS1307(ADDRESS_YEAR, yearZone);
    Write_DS1307(ADDRESS_ZONE, timeZone);
}

void selectTimeZone(void){
    
    temp = getZone();
    switch (timeZone){
        case WAIT:
            if(isButtonAsterisk()){
                modeZone++;
                if(modeZone > 5) modeZone =1;
            }
            if(modeZone == 1){
                LcdClearS();
                switch (getLang())
                {
                    case FR:
                        LcdPrintStringS(0,0,"0.ANGLETERRE GMT");
                        LcdPrintStringS(1,0,"1.FRANCE   GMT+1");
                        break;                       
                    case VN:
                        LcdPrintStringS(0,0,"0.ANH       GMT");
                        LcdPrintStringS(1,0,"1.PHAP    GMT+1");
                        break;
                    default:
                        LcdPrintStringS(0,0,"0.ENGLAND   GMT");
                        LcdPrintStringS(1,0,"1.FRANCE  GMT+1");
                        break;
                }
                if(isButton0()){
                    timeZone = ENG;
                }
                else if(isButton1()){
                    timeZone = FR;
                }
                
            }
            else if(modeZone== 2){
                LcdClearS();
                switch (getLang())
                {
                    default:
                        LcdPrintStringS(0,0,"2.EGYPT    GMT+2");
                        LcdPrintStringS(1,0,"3.RUSSIA   GMT+3");
                        break;
                    case FR:
                        LcdPrintStringS(0,0,"2.EGYPTE   GMT+2");
                        LcdPrintStringS(1,0,"3.RUSSIE   GMT+3");
                        break;
                }

                if(isButton2()){
                    timeZone = EG;
                }
                else if(isButton3()){
                    timeZone = RU;
                }
            }
            else if(modeZone == 3){
                LcdClearS();
                switch (getLang())
                {
                    case FR:
                        LcdPrintStringS(0,0,"4.OMAN     GMT+4");
                        LcdPrintStringS(1,0,"5.MALDIVES GMT+5");
                        break;
                    case VN:
                        LcdPrintStringS(0,0,"4.OMAN     GMT+4");
                        LcdPrintStringS(1,0,"5.MALDIVES GMT+5");
                        break;
                    default:
                        LcdPrintStringS(0,0,"4.OMAN     GMT+4");
                        LcdPrintStringS(1,0,"5.MALDIVES GMT+5");
                        break;
                }
                if(isButton4()){
                    timeZone = OM;
                }
                else if(isButton5()){
                    timeZone = MV;
                }
            }
            else if(modeZone == 4){
                LcdClearS();
                switch (getLang())
                {
                    case FR:
                        LcdPrintStringS(0,0,"6.BHOUTAN  GMT+6");
                        LcdPrintStringS(1,0,"7.VIETNAM  GMT+7");
                        break;
                    case VN:
                        LcdPrintStringS(0,0,"6.BHUTAN   GMT+6");
                        LcdPrintStringS(1,0,"7.VIETNAM  GMT+7");
                        break;
                    default:
                        LcdPrintStringS(0,0,"6.BHUTAN   GMT+6");
                        LcdPrintStringS(1,0,"7.VIETNAM  GMT+7");
                        break;
                }
                if(isButton6()){
                    timeZone = BT;
                }
                else if(isButton7()){
                    timeZone = VN;
                }
            }
            else if(modeZone == 5){
                LcdClearS();
                switch (getLang())
                {
                    case FR:
                        LcdPrintStringS(0,0,"8.CHINE    GMT+8");
                        LcdPrintStringS(1,0,"9.JAPON    GMT+9");
                        break;
                    case VN:
                        LcdPrintStringS(0,0,"8.TRUNG    GMT+8");
                        LcdPrintStringS(1,0,"9.NHATBAN  GMT+9");
                        break;
                    default:
                        LcdPrintStringS(0,0,"8.CHINA    GMT+8");
                        LcdPrintStringS(1,0,"9.JAPAN    GMT+9");
                        break;
                }
                if(isButton8()){
                    timeZone = CN;
                }
                else if(isButton9()){
                    timeZone = JP;
                }
            }
            break;
        case ENG: 
            readTime();
            hourZone += (ENG-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(ENG);
        case FR:
            readTime();
            hourZone += (FR-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(FR);
            break;
        case EG:
            readTime();
            hourZone += (EG-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(EG);
            break;
        case RU:
            readTime();
            hourZone += (RU-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(RU);
            break;
        case OM:
            readTime();
            hourZone += (OM-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(OM);
            break;
        case MV:
            readTime();
            hourZone += (MV-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            //setZone(MV);
            break;
        case BT:
            readTime();
            hourZone += (BT-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(BT);
            break;
        case VN:
            readTime();
            hourZone += (VN-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(VN);
            break;
        case CN:
            readTime();
            hourZone += (CN-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(CN);
            break;
        case JP:
            readTime();
            hourZone += (JP-temp);
            writeTime();
            setDone(0);
            timeZone = WAIT;
            setState(CLOCK);
            setZone(JP);
            break;             
    }
}
