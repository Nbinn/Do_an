#ifndef	_MAIN_H_
#define _MAIN_H_

signed char getZone();
void setZone(signed char timeZone);
void setDone(signed char timeDone);
void setState(unsigned char theState);
unsigned char getDone(void);
void buttonSetting(unsigned char *set);
unsigned char getLang(void);
void setLang(unsigned char language);
#endif