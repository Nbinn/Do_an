/* 
 * File:   childlock.h
 * Author: Tho Nhan
 *
 * Created on December 24, 2021, 10:31 AM
 */

#ifndef CHILDLOCK_H
#define	CHILDLOCK_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* CHILDLOCK_H */

