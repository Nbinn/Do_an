#include "../main.h"
#include "../button_matrix/button.h"
#include "../i2c/i2c.h"
#include "../lcd/lcd.h"
#include "../timer/timer.h"

#define     WAIT    30
#define     LOCK    1
unsigned char lock = WAIT;
unsigned char secondLock = 0;
unsigned char keyLock = 0;
void childLock(){
    switch (lock){
        case WAIT:
            LcdPrintStringS(0,0,"   LOCK CHILD   ");
            LcdPrintStringS(0,0,"  Hit 0 to lock ");
            if(isButton0())
                lock = LOCK;
            break;
        case LOCK:
            buttonSetting(&keyLock);
            secondLock = Read_DS1307(ADDRESS_SECOND);
            if(getDone()){
                if(keyLock == secondLock%10){
                    lock = WAIT;
                }
            }
            break;
    }
}
